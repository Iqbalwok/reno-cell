/**
 * RENO CELL — MAIN JAVASCRIPT
 * File: assets/js/main.js
 * 
 * Interaktivitas utama website:
 * - Sticky Navbar & Mobile Drawer
 * - Smooth Anchor Scrolling
 * - Scroll Reveal via IntersectionObserver
 * - Accordion FAQ
 * - Symptom Checker (Cek Kendala HP Interaktif)
 * - Front-End Contact Form Simulation & WhatsApp Forwarder
 * - Inisialisasi Icon Lucide
 */

document.addEventListener('DOMContentLoaded', function () {
  'use strict';

  /* ------------------------------------------------------------------------
     1. Inisialisasi Lucide Icons
     ------------------------------------------------------------------------ */
  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }

  /* ------------------------------------------------------------------------
     2. Sticky Navbar Behavior
     ------------------------------------------------------------------------ */
  const navbar = document.getElementById('main-navbar');
  if (navbar) {
    const handleScroll = () => {
      if (window.scrollY > 24) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
  }

  /* ------------------------------------------------------------------------
     3. Mobile Navigation Drawer
     ------------------------------------------------------------------------ */
  const hamburgerBtn = document.getElementById('hamburger-btn');
  const mobileDrawer = document.getElementById('mobile-drawer');
  const drawerBackdrop = document.getElementById('mobile-drawer-backdrop');
  const mobileLinks = document.querySelectorAll('.mobile-menu-link');

  function openMobileMenu() {
    if (!hamburgerBtn || !mobileDrawer) return;
    hamburgerBtn.classList.add('is-active');
    mobileDrawer.classList.add('is-open');
    if (drawerBackdrop) drawerBackdrop.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileMenu() {
    if (!hamburgerBtn || !mobileDrawer) return;
    hamburgerBtn.classList.remove('is-active');
    mobileDrawer.classList.remove('is-open');
    if (drawerBackdrop) drawerBackdrop.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  if (hamburgerBtn) {
    hamburgerBtn.addEventListener('click', function () {
      const isOpen = mobileDrawer.classList.contains('is-open');
      if (isOpen) {
        closeMobileMenu();
      } else {
        openMobileMenu();
      }
    });
  }

  if (drawerBackdrop) {
    drawerBackdrop.addEventListener('click', closeMobileMenu);
  }

  mobileLinks.forEach(link => {
    link.addEventListener('click', closeMobileMenu);
  });

  window.addEventListener('resize', function () {
    if (window.innerWidth > 768 && mobileDrawer && mobileDrawer.classList.contains('is-open')) {
      closeMobileMenu();
    }
  });

  /* ------------------------------------------------------------------------
     4. Smooth Scroll untuk In-Page Anchor Links
     ------------------------------------------------------------------------ */
  const anchorLinks = document.querySelectorAll('a[href^="#"]:not([href="#"])');
  anchorLinks.forEach(link => {
    link.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        const navHeight = navbar ? navbar.offsetHeight : 70;
        const targetPosition = targetEl.getBoundingClientRect().top + window.pageYOffset - navHeight - 16;
        window.scrollTo({
          top: targetPosition,
          behavior: 'smooth'
        });
      }
    });
  });

  /* ------------------------------------------------------------------------
     5. Scroll Reveal Animation dengan IntersectionObserver
     ------------------------------------------------------------------------ */
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const revealElements = document.querySelectorAll('.reveal');

  if (!prefersReducedMotion && 'IntersectionObserver' in window && revealElements.length > 0) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      root: null,
      threshold: 0.12,
      rootMargin: '0px 0px -40px 0px'
    });

    revealElements.forEach(el => revealObserver.observe(el));
  } else {
    // Jika reduced motion aktif atau browser lama, tampilkan langsung
    revealElements.forEach(el => el.classList.add('is-revealed'));
  }

  /* ------------------------------------------------------------------------
     6. Accordion FAQ
     ------------------------------------------------------------------------ */
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const trigger = item.querySelector('.faq-trigger');
    const content = item.querySelector('.faq-content');

    if (!trigger || !content) return;

    trigger.addEventListener('click', function () {
      const isOpen = item.classList.contains('is-open');

      // Opsional: Tutup item lain jika ingin model single-open
      faqItems.forEach(otherItem => {
        if (otherItem !== item && otherItem.classList.contains('is-open')) {
          otherItem.classList.remove('is-open');
          const otherContent = otherItem.querySelector('.faq-content');
          if (otherContent) otherContent.style.maxHeight = null;
        }
      });

      if (isOpen) {
        item.classList.remove('is-open');
        content.style.maxHeight = null;
      } else {
        item.classList.add('is-open');
        content.style.maxHeight = content.scrollHeight + 'px';
      }
    });
  });

  // Buka FAQ pertama secara default untuk memberi petunjuk interaksi
  if (faqItems.length > 0) {
    const firstItem = faqItems[0];
    const firstContent = firstItem.querySelector('.faq-content');
    if (firstItem && firstContent) {
      firstItem.classList.add('is-open');
      firstContent.style.maxHeight = firstContent.scrollHeight + 'px';
    }
  }

  /* ------------------------------------------------------------------------
     7. Cek Kendala HP (Interactive Symptom Switcher)
     ------------------------------------------------------------------------ */
  const symptomChips = document.querySelectorAll('.symptom-chip-card');
  const symptomPanel = document.getElementById('symptom-detail-panel');

  if (symptomChips.length > 0 && symptomPanel) {
    const titleEl = symptomPanel.querySelector('.symptom-detail-title');
    const tagEl = symptomPanel.querySelector('.symptom-detail-tag');
    const summaryEl = symptomPanel.querySelector('.symptom-detail-summary');
    const causesEl = symptomPanel.querySelector('.symptom-detail-causes');
    const tipsEl = symptomPanel.querySelector('.symptom-detail-tips');
    const consultBtn = symptomPanel.querySelector('.symptom-consult-btn');
    const basePhone = consultBtn ? consultBtn.getAttribute('data-phone') : '6281234567890';

    symptomChips.forEach(chip => {
      chip.addEventListener('click', function () {
        symptomChips.forEach(c => c.classList.remove('active'));
        this.classList.add('active');

        // Ambil data atribut dari kartu gejala
        const title = this.getAttribute('data-title');
        const tag = this.getAttribute('data-tag');
        const summary = this.getAttribute('data-summary');
        const causes = this.getAttribute('data-causes');
        const tips = this.getAttribute('data-tips');
        const waText = this.getAttribute('data-wa');

        // Efek transisi halus pada teks
        symptomPanel.style.opacity = '0.7';
        setTimeout(() => {
          if (titleEl) titleEl.textContent = title;
          if (tagEl) tagEl.textContent = tag;
          if (summaryEl) summaryEl.textContent = summary;
          if (causesEl) causesEl.textContent = causes;
          if (tipsEl) tipsEl.textContent = tips;
          if (consultBtn) {
            consultBtn.href = `https://wa.me/${basePhone}?text=${encodeURIComponent(waText)}`;
          }
          symptomPanel.style.opacity = '1';
        }, 150);
      });
    });
  }

  /* ------------------------------------------------------------------------
     8. Front-End Contact Form Simulation & WhatsApp Forwarder
     ------------------------------------------------------------------------ */
  const contactForm = document.getElementById('front-contact-form');
  const formFeedback = document.getElementById('form-simulation-alert');

  if (contactForm && formFeedback) {
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const nameInput = document.getElementById('contact-name');
      const waInput = document.getElementById('contact-phone');
      const deviceInput = document.getElementById('contact-device');
      const issueInput = document.getElementById('contact-issue');
      const notesInput = document.getElementById('contact-notes');

      const nameVal = nameInput ? nameInput.value.trim() : '';
      const waVal = waInput ? waInput.value.trim() : '';
      const deviceVal = deviceInput ? deviceInput.value.trim() : '';
      const issueVal = issueInput ? issueInput.value : '';
      const notesVal = notesInput ? notesInput.value.trim() : '';

      if (!nameVal || !waVal) {
        alert('Mohon lengkapi Nama dan Nomor Kontak Anda.');
        return;
      }

      // Format WhatsApp Pesan Otomatis dari Form
      const rawPhoneTarget = contactForm.getAttribute('data-target-phone') || '6281234567890';
      const formattedWaMessage = `Halo Reno Cell, saya mengisi formulir di website:\n- Nama: ${nameVal}\n- Kontak Saya: ${waVal}\n- Tipe HP: ${deviceVal || 'Belum diisi'}\n- Kendala: ${issueVal || 'Konsultasi Umum'}\n- Catatan: ${notesVal || 'Tidak ada'}\n\nMohon informasi konsultasi lebih lanjut. Terima kasih!`;
      const waDirectUrl = `https://wa.me/${rawPhoneTarget}?text=${encodeURIComponent(formattedWaMessage)}`;

      // Tampilkan feedback simulasi
      formFeedback.innerHTML = `
        <div style="font-weight: 700; margin-bottom: 6px; color: var(--color-olive-dark);">
          ✓ Simulasi Formulir Berhasil Ditinjau!
        </div>
        <p style="margin-bottom: 10px; font-size: 0.76rem;">
          Halo <strong>${escapeHTML(nameVal)}</strong>, ini adalah simulasi form front-end demo (tidak disimpan ke server/database). Untuk langsung terhubung dan mengirimkan data kendala Anda ke teknisi Reno Cell, klik tombol di bawah:
        </p>
        <a href="${waDirectUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm" style="display: inline-flex;">
          <i data-lucide="message-circle" style="width: 15px; height: 15px;"></i> Kirim Data Ini ke WhatsApp Reno Cell
        </a>
      `;
      formFeedback.classList.add('is-visible');

      // Refresh icons if lucide is active
      if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
      }

      // Scroll halus ke feedback
      formFeedback.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
  }

  function escapeHTML(str) {
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }

});
