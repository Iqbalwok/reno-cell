/**
 * RENO CELL — ESTIMATOR BIAYA SERVIS (FRONT-END SIMULASI)
 * File: assets/js/estimator.js
 * 
 * Modul interaktif untuk menghitung perkiraan estimasi biaya perbaikan
 * berdasarkan data contoh/demo di JavaScript.
 * Catatan: Semua harga demo ditandai dengan jelas sebagai simulasi perkiraan awal.
 */

(function () {
  'use strict';

  // Data Model Perangkat berdasarkan Merek
  const deviceModels = {
    apple: [
      { id: 'iphone-11', name: 'iPhone 11' },
      { id: 'iphone-12', name: 'iPhone 12 / 12 Pro' },
      { id: 'iphone-13', name: 'iPhone 13 / 13 Pro' },
      { id: 'iphone-14', name: 'iPhone 14 / 14 Pro' },
      { id: 'iphone-other', name: 'iPhone Model Lainnya' }
    ],
    samsung: [
      { id: 'sam-a5x', name: 'Galaxy A Series (A52 / A53 / A54)' },
      { id: 'sam-a1x', name: 'Galaxy A Series Entry (A12 / A14)' },
      { id: 'sam-sx', name: 'Galaxy S Series (S20 / S21 / S22 / S23)' },
      { id: 'sam-other', name: 'Samsung Seri Lainnya' }
    ],
    xiaomi: [
      { id: 'mi-poco', name: 'POCO Series (X3 / F3 / F4)' },
      { id: 'mi-series', name: 'Xiaomi 11 / 12 / 13 Series' },
      { id: 'mi-other', name: 'Xiaomi Model Lainnya' }
    ],
    redmi: [
      { id: 'redmi-note10', name: 'Redmi Note 10 / 10 Pro' },
      { id: 'redmi-note11', name: 'Redmi Note 11 / 12 Pro' },
      { id: 'redmi-entry', name: 'Redmi 9 / 10 / 12 Entry' },
      { id: 'redmi-other', name: 'Redmi Seri Lainnya' }
    ],
    oppo: [
      { id: 'oppo-reno', name: 'OPPO Reno Series (Reno 6 / 7 / 8 / 10)' },
      { id: 'oppo-a', name: 'OPPO A Series (A57 / A77 / A96)' },
      { id: 'oppo-other', name: 'OPPO Model Lainnya' }
    ],
    vivo: [
      { id: 'vivo-v', name: 'vivo V Series (V23 / V25 / V27)' },
      { id: 'vivo-y', name: 'vivo Y Series (Y21 / Y35 / Y36)' },
      { id: 'vivo-other', name: 'vivo Model Lainnya' }
    ],
    realme: [
      { id: 'realme-num', name: 'realme Number Series (9 / 10 / 11)' },
      { id: 'realme-c', name: 'realme C Series (C35 / C53 / C55)' },
      { id: 'realme-other', name: 'realme Model Lainnya' }
    ]
  };

  // Matrix Estimasi Harga Demo Berdasarkan Jenis Kerusakan & Kategori Merek
  // Format harga merupakan perkiraan rentang (contoh simulasi)
  const damageEstimates = {
    'lcd': {
      label: 'Ganti LCD & Touchscreen',
      duration: '45 - 90 Menit',
      warranty: 'Garansi 30 - 90 Hari',
      priceTiers: {
        apple: 'Rp 450.000 – Rp 1.450.000*',
        samsung: 'Rp 350.000 – Rp 1.250.000*',
        xiaomi: 'Rp 280.000 – Rp 750.000*',
        redmi: 'Rp 250.000 – Rp 650.000*',
        oppo: 'Rp 280.000 – Rp 700.000*',
        vivo: 'Rp 280.000 – Rp 700.000*',
        realme: 'Rp 250.000 – Rp 650.000*'
      }
    },
    'baterai': {
      label: 'Penggantian Baterai Baru',
      duration: '30 - 60 Menit',
      warranty: 'Garansi 30 Hari',
      priceTiers: {
        apple: 'Rp 280.000 – Rp 550.000*',
        samsung: 'Rp 180.000 – Rp 350.000*',
        xiaomi: 'Rp 160.000 – Rp 280.000*',
        redmi: 'Rp 150.000 – Rp 260.000*',
        oppo: 'Rp 160.000 – Rp 290.000*',
        vivo: 'Rp 160.000 – Rp 290.000*',
        realme: 'Rp 150.000 – Rp 270.000*'
      }
    },
    'charger': {
      label: 'Port Charger / Konektor Cas',
      duration: '30 - 60 Menit',
      warranty: 'Garansi 14 - 30 Hari',
      priceTiers: {
        apple: 'Rp 200.000 – Rp 400.000*',
        samsung: 'Rp 120.000 – Rp 250.000*',
        xiaomi: 'Rp 100.000 – Rp 200.000*',
        redmi: 'Rp 90.000 – Rp 180.000*',
        oppo: 'Rp 110.000 – Rp 220.000*',
        vivo: 'Rp 110.000 – Rp 220.000*',
        realme: 'Rp 100.000 – Rp 200.000*'
      }
    },
    'kamera': {
      label: 'Modul Kamera Depan/Belakang',
      duration: '60 - 120 Menit',
      warranty: 'Garansi 30 Hari',
      priceTiers: {
        apple: 'Rp 350.000 – Rp 950.000*',
        samsung: 'Rp 250.000 – Rp 650.000*',
        xiaomi: 'Rp 180.000 – Rp 400.000*',
        redmi: 'Rp 160.000 – Rp 350.000*',
        oppo: 'Rp 180.000 – Rp 420.000*',
        vivo: 'Rp 180.000 – Rp 420.000*',
        realme: 'Rp 160.000 – Rp 380.000*'
      }
    },
    'speaker': {
      label: 'Speaker Musik / Earpiece / Mic',
      duration: '30 - 60 Menit',
      warranty: 'Garansi 14 - 30 Hari',
      priceTiers: {
        apple: 'Rp 180.000 – Rp 350.000*',
        samsung: 'Rp 120.000 – Rp 220.000*',
        xiaomi: 'Rp 90.000 – Rp 180.000*',
        redmi: 'Rp 90.000 – Rp 170.000*',
        oppo: 'Rp 100.000 – Rp 190.000*',
        vivo: 'Rp 100.000 – Rp 190.000*',
        realme: 'Rp 90.000 – Rp 180.000*'
      }
    },
    'tombol': {
      label: 'Fleksibel Tombol Power / Volume',
      duration: '30 - 60 Menit',
      warranty: 'Garansi 14 Hari',
      priceTiers: {
        apple: 'Rp 180.000 – Rp 320.000*',
        samsung: 'Rp 110.000 – Rp 200.000*',
        xiaomi: 'Rp 90.000 – Rp 170.000*',
        redmi: 'Rp 80.000 – Rp 150.000*',
        oppo: 'Rp 90.000 – Rp 170.000*',
        vivo: 'Rp 90.000 – Rp 170.000*',
        realme: 'Rp 80.000 – Rp 160.000*'
      }
    },
    'mesin': {
      label: 'Pemeriksaan Mesin / Mati Total',
      duration: '1 - 3 Hari Kerja',
      warranty: 'Garansi 30 Hari',
      priceTiers: {
        apple: 'Mulai Rp 350.000 (Sesuai Cek)',
        samsung: 'Mulai Rp 250.000 (Sesuai Cek)',
        xiaomi: 'Mulai Rp 200.000 (Sesuai Cek)',
        redmi: 'Mulai Rp 180.000 (Sesuai Cek)',
        oppo: 'Mulai Rp 200.000 (Sesuai Cek)',
        vivo: 'Mulai Rp 200.000 (Sesuai Cek)',
        realme: 'Mulai Rp 180.000 (Sesuai Cek)'
      }
    }
  };

  // Elemen DOM Estimator
  const brandSelect = document.getElementById('est-brand');
  const modelSelect = document.getElementById('est-model');
  const damageSelect = document.getElementById('est-damage');
  const priceDisplay = document.getElementById('est-price-value');
  const durationDisplay = document.getElementById('est-duration-value');
  const warrantyDisplay = document.getElementById('est-warranty-value');
  const waBtn = document.getElementById('est-wa-btn');

  if (!brandSelect || !damageSelect || !priceDisplay || !waBtn) {
    return; // Exit jika elemen tidak ada di halaman
  }

  // Ambil nomor WhatsApp dari atribut data atau fallback
  const rawWaNumber = waBtn.getAttribute('data-phone') || '6281234567890';

  /**
   * Mengisi pilihan model HP sesuai merek yang dipilih
   */
  function populateModels(brand) {
    if (!modelSelect) return;
    modelSelect.innerHTML = '';

    const models = deviceModels[brand] || [
      { id: 'general', name: 'Semua Seri / Tipe Lainnya' }
    ];

    models.forEach(function (item) {
      const opt = document.createElement('option');
      opt.value = item.id;
      opt.textContent = item.name;
      modelSelect.appendChild(opt);
    });
  }

  /**
   * Menghitung dan memperbarui estimasi tampilan
   */
  function updateEstimation() {
    const brand = brandSelect.value;
    const damage = damageSelect.value;
    const brandText = brandSelect.options[brandSelect.selectedIndex].text;
    const modelText = modelSelect && modelSelect.options.length > 0
      ? modelSelect.options[modelSelect.selectedIndex].text
      : 'Perangkat Smartphone';
    const damageText = damageSelect.options[damageSelect.selectedIndex].text;

    const damageInfo = damageEstimates[damage];

    if (damageInfo && damageInfo.priceTiers[brand]) {
      const priceRange = damageInfo.priceTiers[brand];
      priceDisplay.textContent = priceRange;
      if (durationDisplay) durationDisplay.textContent = damageInfo.duration;
      if (warrantyDisplay) warrantyDisplay.textContent = damageInfo.warranty;

      // Update link WhatsApp dengan parameter spesifik
      const waText = `Halo Reno Cell, saya melihat estimasi di website untuk:\n- Merek: ${brandText}\n- Model: ${modelText}\n- Kerusakan: ${damageText}\n- Estimasi Demo: ${priceRange}\n\nApakah stok spare part tersedia dan kapan saya bisa datang untuk pemeriksaan? Terima kasih.`;
      waBtn.href = `https://wa.me/${rawWaNumber}?text=${encodeURIComponent(waText)}`;
    } else {
      priceDisplay.textContent = 'Hubungi kami untuk estimasi';
      if (durationDisplay) durationDisplay.textContent = 'Konfirmasi teknisi';
      if (warrantyDisplay) warrantyDisplay.textContent = 'Sesuai ketentuan';

      const waText = `Halo Reno Cell, saya ingin menanyakan perkiraan biaya dan ketersediaan spare part untuk:\n- Merek: ${brandText}\n- Model: ${modelText}\n- Kerusakan: ${damageText}\n\nMohon info estimasi biayanya. Terima kasih.`;
      waBtn.href = `https://wa.me/${rawWaNumber}?text=${encodeURIComponent(waText)}`;
    }
  }

  // Event Listeners
  brandSelect.addEventListener('change', function () {
    populateModels(this.value);
    updateEstimation();
  });

  if (modelSelect) {
    modelSelect.addEventListener('change', updateEstimation);
  }

  damageSelect.addEventListener('change', updateEstimation);

  // Inisialisasi awal saat halaman termuat
  populateModels(brandSelect.value);
  updateEstimation();

})();
