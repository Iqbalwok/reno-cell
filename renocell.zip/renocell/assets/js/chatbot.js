/**
 * RENO CELL — CHATBOT FRONT-END (RENO CELL ASSISTANT)
 * File: assets/js/chatbot.js
 * 
 * Widget Chatbot Customer Service Front-End berbasis keyword response demo.
 * Membantu pengunjung mendapatkan jawaban cepat seputar layanan, jam buka,
 * perkiraan perbaikan, serta opsi meneruskan chat ke WhatsApp.
 * 
 * PENTING: Chatbot ini merupakan simulasi frontend demo dan tidak menggunakan
 * API key eksternal ataupun klaim AI sungguhan.
 */

(function () {
  'use strict';

  // State
  let isChatOpen = false;

  // Elemen DOM Chatbot
  const launcherBtn = document.getElementById('chat-launcher-btn');
  const modalPanel = document.getElementById('chatbot-modal-panel');
  const closeBtn = document.getElementById('chatbot-close-btn');
  const messagesBody = document.getElementById('chatbot-messages-body');
  const inputField = document.getElementById('chatbot-input-field');
  const sendBtn = document.getElementById('chatbot-send-btn');
  const quickRepliesContainer = document.getElementById('chatbot-quick-replies');

  if (!launcherBtn || !modalPanel || !messagesBody || !inputField || !sendBtn) {
    return;
  }

  // Ambil nomor WhatsApp dari launcher atau fallback
  const rawWaPhone = launcherBtn.getAttribute('data-phone') || '6281234567890';

  /**
   * Helper: Format Jam sekarang (HH:mm)
   */
  function getCurrentTimeString() {
    const now = new Date();
    const hrs = String(now.getHours()).padStart(2, '0');
    const mins = String(now.getMinutes()).padStart(2, '0');
    return `${hrs}:${mins}`;
  }

  /**
   * Menambahkan bubble chat ke dalam messages body
   */
  function appendMessage(sender, text, actionButtons = []) {
    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${sender}`;

    const textEl = document.createElement('div');
    textEl.className = 'chat-bubble-content';
    textEl.innerHTML = text;
    bubble.appendChild(textEl);

    // Jika ada action button tambahan di dalam bubble
    if (actionButtons && actionButtons.length > 0) {
      const btnGroup = document.createElement('div');
      btnGroup.style.display = 'flex';
      btnGroup.style.flexWrap = 'wrap';
      btnGroup.style.gap = '6px';
      btnGroup.style.marginTop = '10px';

      actionButtons.forEach(action => {
        const actionBtn = document.createElement('a');
        actionBtn.href = action.url;
        actionBtn.className = 'btn btn-sage btn-sm';
        actionBtn.style.fontSize = '0.7rem';
        actionBtn.style.padding = '5px 10px';
        actionBtn.innerHTML = action.label;
        if (action.targetBlank) {
          actionBtn.target = '_blank';
          actionBtn.rel = 'noopener noreferrer';
        }
        btnGroup.appendChild(actionBtn);
      });
      bubble.appendChild(btnGroup);
    }

    const timeEl = document.createElement('div');
    timeEl.className = 'chat-time';
    timeEl.textContent = getCurrentTimeString();
    bubble.appendChild(timeEl);

    messagesBody.appendChild(bubble);
    messagesBody.scrollTop = messagesBody.scrollHeight;
  }

  /**
   * Toggle Buka / Tutup Panel Chatbot
   */
  function toggleChatbot(openState) {
    isChatOpen = (typeof openState === 'boolean') ? openState : !isChatOpen;
    if (isChatOpen) {
      modalPanel.classList.add('is-open');
      inputField.focus();
    } else {
      modalPanel.classList.remove('is-open');
    }
  }

  /**
   * Engine Pencocokan Keyword Respons Demo
   */
  function generateBotReply(userText) {
    const text = userText.toLowerCase().trim();

    // 1. Layanan / Service
    if (text.includes('layanan') || text.includes('servis apa') || text.includes('bisa apa') || text.includes('menu')) {
      return {
        text: 'Reno Cell melayani berbagai perbaikan smartphone seperti: Ganti LCD & Touchscreen, Ganti Baterai, Perbaikan Port Charger, Kamera, Speaker/Mic, Tombol Fisik, HP Mati Total, dan Perbaikan Software (Bootloop).',
        actions: [
          { label: 'Lihat Daftar Layanan', url: '#layanan' },
          { label: 'Chat WhatsApp Teknisi', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, saya ingin menanyakan layanan servis smartphone.')}`, targetBlank: true }
        ]
      };
    }

    // 2. LCD & Layar
    if (text.includes('lcd') || text.includes('layar') || text.includes('retak') || text.includes('pecah') || text.includes('garis') || text.includes('blank')) {
      return {
        text: 'Untuk kerusakan LCD/layar (retak, blank, atau garis), pengerjaan rata-rata memakan waktu 45–90 menit jika suku cadang tersedia. Kami menyediakan pilihan suku cadang yang disesuaikan dengan kebutuhan Anda.',
        actions: [
          { label: 'Cek Estimasi LCD', url: '#estimasi' },
          { label: 'Konsultasi Layar via WA', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, layar HP saya retak/bermasalah. Mohon info estimasi biaya dan stok layarnya.')}`, targetBlank: true }
        ]
      };
    }

    // 3. Baterai
    if (text.includes('baterai') || text.includes('battery') || text.includes('drop') || text.includes('kembung') || text.includes('boros')) {
      return {
        text: 'Tanda baterai perlu diganti antara lain: cepat habis, drop mendadak di atas 20%, atau bodi belakang mulai terdorong kembung. Proses ganti baterai umumnya 30–60 menit dan dapat ditunggu.',
        actions: [
          { label: 'Hitung Estimasi Baterai', url: '#estimasi' },
          { label: 'Tanya Baterai via WA', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, baterai HP saya cepat drop/kembung. Mau tanya ketersediaan baterai pengganti.')}`, targetBlank: true }
        ]
      };
    }

    // 4. Charger & Cas
    if (text.includes('cas') || text.includes('charger') || text.includes('konektor') || text.includes('tipe c') || text.includes('type c') || text.includes('lightning') || text.includes('colokan')) {
      return {
        text: 'Masalah charging sering kali disebabkan oleh penumpukan debu/serat di lubang port atau pin konektor aus. Kami memeriksa dan membersihkannya terlebih dahulu sebelum memutuskan perlu penggantian part.',
        actions: [
          { label: 'Konsultasi Port Cas', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, HP saya tidak bisa dicas. Mau tanya pengecekan konektor casnya.')}`, targetBlank: true }
        ]
      };
    }

    // 5. HP Mati Total / Air
    if (text.includes('mati') || text.includes('matot') || text.includes('air') || text.includes('nyemplung') || text.includes('konslet')) {
      return {
        text: '<strong>Tips Penting:</strong> Jika HP terkena air atau mati mendadak, JANGAN menghubungkannya ke charger. Hal ini mencegah konsleting yang lebih parah pada komponen IC motherboard. Segera bawa ke tempat kami untuk dibongkar dan dikeringkan secara profesional.',
        actions: [
          { label: 'Hubungi Darurat WA', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, HP saya mati mendadak/kena air. Butuh penanganan cepat.')}`, targetBlank: true }
        ]
      };
    }

    // 6. Biaya / Harga / Estimasi
    if (text.includes('harga') || text.includes('biaya') || text.includes('berapa') || text.includes('estimasi') || text.includes('tarif') || text.includes('ongkos')) {
      return {
        text: 'Estimasi biaya perbaikan bergantung pada merek, tipe model, dan jenis kerusakan. Anda dapat mencoba alat simulasi estimasi di halaman ini atau mengirimkan detail tipe HP Anda ke WhatsApp.',
        actions: [
          { label: 'Buka Form Estimasi', url: '#estimasi' },
          { label: 'Tanya Harga di WA', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, saya ingin menanyakan perkiraan biaya servis untuk HP saya.')}`, targetBlank: true }
        ]
      };
    }

    // 7. Alamat / Lokasi / Jam Buka
    if (text.includes('alamat') || text.includes('lokasi') || text.includes('dimana') || text.includes('tempat') || text.includes('buka jam') || text.includes('jam operasional') || text.includes('toko')) {
      return {
        text: '<strong>Informasi Reno Cell:</strong><br>• Alamat: Jl. Anggrek Cendrawasih No. 28 (Area Demo Bisnis), Jakarta Barat.<br>• Jam Buka: Senin – Sabtu: 09.00 – 20.00 WIB, Minggu: 10.00 – 17.00 WIB.',
        actions: [
          { label: 'Lihat Area Peta', url: '#kontak' },
          { label: 'Petunjuk Arah via WA', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, boleh minta petunjuk arah lokasi toko servis?')}`, targetBlank: true }
        ]
      };
    }

    // 8. Garansi
    if (text.includes('garansi') || text.includes('jaminan') || text.includes('rusak lagi')) {
      return {
        text: 'Setiap perbaikan di Reno Cell dilengkapi dengan garansi layanan dan spare part sesuai kesepakatan (umumnya 14 hingga 90 hari tergantung jenis komponen). Garansi mencakup fungsi part yang diganti.',
        actions: [
          { label: 'Baca FAQ Garansi', url: '#faq' }
        ]
      };
    }

    // 9. Berapa lama / Durasi
    if (text.includes('berapa lama') || text.includes('waktu') || text.includes('ditunggu') || text.includes('bisa ditunggu')) {
      return {
        text: 'Perbaikan ringan seperti ganti baterai, LCD, dan port charger rata-rata berkisar 30 - 90 menit dan bisa ditunggu. Untuk pemeriksaan motherboard atau HP mati total membutuhkan waktu diagnostik 1–3 hari kerja.',
        actions: [
          { label: 'Tanya Jadwal di WA', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, apakah perbaikan HP hari ini bisa langsung ditunggu?')}`, targetBlank: true }
        ]
      };
    }

    // 10. Salam / Sapaan
    if (text.includes('halo') || text.includes('hai') || text.includes('selamat') || text.includes('pagi') || text.includes('siang') || text.includes('sore') || text.includes('malam')) {
      return {
        text: 'Halo! Selamat datang di Reno Cell Assistant. Ada kendala pada smartphone yang ingin kami bantu cek?',
        actions: []
      };
    }

    // 11. Terima Kasih
    if (text.includes('terima kasih') || text.includes('makasih') || text.includes('thanks') || text.includes('ok')) {
      return {
        text: 'Sama-sama! Senang bisa membantu Anda. Jika ingin konsultasi langsung dengan teknisi ramah kami, jangan ragu untuk klik WhatsApp di bawah ini ya.',
        actions: [
          { label: 'Chat WhatsApp', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, terima kasih informasinya. Saya ingin konsultasi lebih lanjut.')}`, targetBlank: true }
        ]
      };
    }

    // Default Fallback
    return {
      text: 'Terima kasih atas pertanyaannya. Untuk memastikan kendala perangkat Anda mendapatkan solusi yang paling akurat, tim teknisi kami siap membantu Anda secara langsung via WhatsApp.',
      actions: [
        { label: 'Chat Teknisi di WhatsApp', url: `https://wa.me/${rawWaPhone}?text=${encodeURIComponent('Halo Reno Cell, saya ingin menanyakan hal terkait: ' + userText)}`, targetBlank: true },
        { label: 'Cek Halaman Estimasi', url: '#estimasi' }
      ]
    };
  }

  /**
   * Menangani pengiriman pesan user
   */
  function handleSendMessage() {
    const rawText = inputField.value.trim();
    if (!rawText) return;

    // Tampilkan pesan user
    appendMessage('user', escapeHTML(rawText));
    inputField.value = '';

    // Efek typing delay sejenak (400ms) agar terasa natural dan nyaman
    setTimeout(() => {
      const botResponse = generateBotReply(rawText);
      appendMessage('bot', botResponse.text, botResponse.actions);
    }, 400);
  }

  /**
   * Escape helper sederhana untuk input user
   */
  function escapeHTML(str) {
    const p = document.createElement('p');
    p.appendChild(document.createTextNode(str));
    return p.innerHTML;
  }

  // Event Listeners
  launcherBtn.addEventListener('click', function (e) {
    e.preventDefault();
    toggleChatbot();
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', function () {
      toggleChatbot(false);
    });
  }

  sendBtn.addEventListener('click', handleSendMessage);

  inputField.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendMessage();
    }
  });

  // Delegasi event untuk Quick Reply Chips
  if (quickRepliesContainer) {
    quickRepliesContainer.addEventListener('click', function (e) {
      const targetBtn = e.target.closest('.quick-reply-btn');
      if (!targetBtn) return;

      const replyText = targetBtn.textContent.trim();
      appendMessage('user', replyText);

      setTimeout(() => {
        const botResponse = generateBotReply(replyText);
        appendMessage('bot', botResponse.text, botResponse.actions);
      }, 350);
    });
  }

  // Tutup panel jika klik di luar pada layar kecil
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && isChatOpen) {
      toggleChatbot(false);
    }
  });

})();
