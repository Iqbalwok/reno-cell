<?php
/**
 * RENO CELL - Website Company Profile & Smartphone Repair
 * Central Configuration File
 * 
 * Semua konfigurasi umum seperti nomor WhatsApp, alamat, jam operasional,
 * dan data layanan tersentralisasi di sini agar mudah disesuaikan.
 */

// Informasi Bisnis (Placeholder aman & terpusat)
$siteConfig = [
    'brand_name'       => 'Reno Cell',
    'tagline'          => 'Solusi Servis Smartphone Ramah & Transparan',
    'meta_description' => 'Reno Cell membantu Anda mengatasi berbagai masalah smartphone dengan pelayanan yang ramah, penjelasan yang jelas, dan proses servis yang nyaman.',
    
    // Kontak & Komunikasi (Gunakan nomor resmi Anda saat live)
    'whatsapp_number'  => '6281234567890', // Format internasional tanpa +, contoh: 6281234567890
    'whatsapp_display' => '+62 812-3456-7890',
    'email'            => 'halo@renocell-demo.id',
    
    // Alamat & Jam Operasional (Placeholder jelas untuk demo)
    'address_street'   => 'Jl. Anggrek Cendrawasih No. 28 (Area Demo Bisnis)',
    'address_city'     => 'Jakarta Barat, DKI Jakarta 11480',
    'google_maps_url'  => 'https://maps.google.com/?q=Smartphone+Repair+Service',
    
    'hours_weekdays'   => 'Senin – Sabtu: 09.00 – 20.00 WIB',
    'hours_sunday'     => 'Minggu: 10.00 – 17.00 WIB',
    'status_note'      => 'Buka Setiap Hari (Kecuali Hari Libur Nasional Tertentu)',
    
    // Media Sosial (Placeholder)
    'socials' => [
        'instagram' => 'https://instagram.com/renocell.demo',
        'tiktok'    => 'https://tiktok.com/@renocell.demo',
        'facebook'  => 'https://facebook.com/renocell.demo'
    ],
    
    // Default WhatsApp Message
    'default_wa_message' => 'Halo Reno Cell, saya ingin konsultasi mengenai perbaikan smartphone saya.'
];

/**
 * Helper: Menghasilkan link WhatsApp dengan pesan terformat
 */
function get_whatsapp_url($custom_message = null) {
    global $siteConfig;
    $msg = $custom_message ?: $siteConfig['default_wa_message'];
    return 'https://wa.me/' . $siteConfig['whatsapp_number'] . '?text=' . rawurlencode($msg);
}

/**
 * Helper: Mendapatkan base URL otomatis untuk mendukung XAMPP subfolder maupun root domain
 */
function get_base_url() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
    $scriptDir = ($scriptDir === '/' || $scriptDir === '\\') ? '' : $scriptDir;
    return $protocol . $host . $scriptDir;
}

/**
 * Data Layanan Servis Reno Cell
 */
$servicesData = [
    [
        'id'          => 'lcd-touchscreen',
        'title'       => 'Ganti LCD & Touchscreen',
        'category'    => 'Layar & Display',
        'description' => 'Solusi layar retak, garis warna, touch error, ghost touch, hingga layar blank hitam dengan berbagai pilihan grade spare part.',
        'image'       => 'assets/images/service-lcd.jpg',
        'duration'    => '45 - 90 Menit',
        'wa_intent'   => 'Halo Reno Cell, saya ingin konsultasi ganti LCD untuk HP saya.'
    ],
    [
        'id'          => 'baterai',
        'title'       => 'Penggantian Baterai',
        'category'    => 'Daya & Baterai',
        'description' => 'Atasi baterai cepat habis, kembung, persentase loncat, atau mati mendadak saat daya masih tersisa.',
        'image'       => 'assets/images/service-battery.jpg',
        'duration'    => '30 - 60 Menit',
        'wa_intent'   => 'Halo Reno Cell, saya ingin tanya ketersediaan dan biaya penggantian baterai HP.'
    ],
    [
        'id'          => 'port-charger',
        'title'       => 'Perbaikan Port Charger',
        'category'    => 'Konektivitas',
        'description' => 'Penanganan port USB/Type-C/Lightning yang longgar, tidak mengisi daya, lambat charging, atau kemasukan kotoran.',
        'image'       => 'assets/images/service-charging.jpg',
        'duration'    => '30 - 60 Menit',
        'wa_intent'   => 'Halo Reno Cell, port charger HP saya bermasalah/tidak bisa ngecas, mohon info estimasinya.'
    ],
    [
        'id'          => 'speaker-mic',
        'title'       => 'Speaker & Mikrofon',
        'category'    => 'Audio Hardware',
        'description' => 'Perbaikan suara panggilan kresek-kresek, suara lawan bicara tidak terdengar, speaker musik pecah, atau mic mati.',
        'image'       => 'assets/images/service-speaker.jpg',
        'duration'    => '45 - 90 Menit',
        'wa_intent'   => 'Halo Reno Cell, speaker/mic smartphone saya suaranya kecil/rusak, ingin konsultasi servis.'
    ],
    [
        'id'          => 'kamera',
        'title'       => 'Perbaikan Kamera',
        'category'    => 'Optik & Sensor',
        'description' => 'Penggantian lensa kaca pecah, kamera buram, autofocus getar, atau aplikasi kamera freeze saat dibuka.',
        'image'       => 'assets/images/service-camera.jpg',
        'duration'    => '60 - 120 Menit',
        'wa_intent'   => 'Halo Reno Cell, kamera HP saya bermasalah (buram/rusak), mohon saran perbaikannya.'
    ],
    [
        'id'          => 'tombol-fisik',
        'title'       => 'Tombol Power & Volume',
        'category'    => 'Hardware Mekanis',
        'description' => 'Servis fleksibel tombol yang macet, mendem, tidak merespons, atau restart terus-menerus akibat tombol power terjepit.',
        'image'       => 'assets/images/service-button.jpg',
        'duration'    => '30 - 60 Menit',
        'wa_intent'   => 'Halo Reno Cell, tombol power/volume HP saya macet, apakah bisa diperiksa?'
    ],
    [
        'id'          => 'mati-total',
        'title'       => 'Pemeriksaan HP Mati Total',
        'category'    => 'Motherboard & IC',
        'description' => 'Diagnostik menyeluruh dengan instrumen ukur untuk kasus HP mati akibat jatuh, konsleting, atau tersiram air.',
        'image'       => 'assets/images/service-deadphone.jpg',
        'duration'    => '1 - 3 Hari Kerja',
        'wa_intent'   => 'Halo Reno Cell, HP saya mati total dan tidak merespons saat dicas, ingin cek awal.'
    ],
    [
        'id'          => 'software-troubleshoot',
        'title'       => 'Software & Bootloop',
        'category'    => 'Sistem Operasi',
        'description' => 'Penanganan HP stuck di logo (bootloop), lupa pola/sandi (dengan bukti kepemilikan sah), update gagal, atau sistem error.',
        'image'       => 'assets/images/service-software.jpg',
        'duration'    => '60 - 120 Menit',
        'wa_intent'   => 'Halo Reno Cell, sistem HP saya bootloop/stuck di logo, mohon bantuan perbaikan software.'
    ]
];

/**
 * Data Merek Smartphone yang Didukung
 */
$brandsData = [
    ['name' => 'Apple / iPhone', 'code' => 'apple', 'badge' => 'iOS'],
    ['name' => 'Samsung',        'code' => 'samsung', 'badge' => 'Galaxy Series'],
    ['name' => 'Xiaomi',         'code' => 'xiaomi', 'badge' => 'Mi / POCO'],
    ['name' => 'Redmi',          'code' => 'redmi', 'badge' => 'Redmi Series'],
    ['name' => 'OPPO',           'code' => 'oppo', 'badge' => 'Reno / A Series'],
    ['name' => 'vivo',           'code' => 'vivo', 'badge' => 'V / Y Series'],
    ['name' => 'realme',         'code' => 'realme', 'badge' => 'Number / C Series']
];

/**
 * Gejala & Masalah Smartphone untuk Section "Cek Kendala HP"
 */
$symptomsData = [
    [
        'id'       => 'layar-pecah',
        'icon'     => 'smartphone',
        'title'    => 'Layar Pecah / Bergaris',
        'tag'      => 'Display',
        'summary'  => 'Kaca luar retak, muncul garis vertikal/horizontal, atau ada noda tinta hitam.',
        'causes'   => 'Benturan fisik keras, tekanan berlebih di saku, atau kerusakan modul AMOLED/IPS.',
        'tips'     => 'Hindari menekan area yang retak dan jangan terkena air. Segera cadangkan data jika layar masih merespons.',
        'wa_text'  => 'Halo Reno Cell, layar HP saya retak/bergaris. Mau tanya estimasi perbaikan dan pilihan layarnya.'
    ],
    [
        'id'       => 'baterai-drop',
        'icon'     => 'battery-warning',
        'title'    => 'Baterai Cepat Habis',
        'tag'      => 'Baterai',
        'summary'  => 'Baterai boros drastis, drop dari 40% langsung mati, atau bodi belakang terasa menggelembung.',
        'causes'   => 'Siklus hidup sel baterai telah menurun (health degradasi) atau konsumsi daya latar belakang tidak wajar.',
        'tips'     => 'Hentikan penggunaan charger non-standar dan jangan biarkan HP diisi daya semalaman saat sudah penuh.',
        'wa_text'  => 'Halo Reno Cell, baterai HP saya cepat sekali drop/kembung. Ingin konsultasi penggantian baterai baru.'
    ],
    [
        'id'       => 'tidak-bisa-cas',
        'icon'     => 'zap-off',
        'title'    => 'Tidak Bisa Dicas',
        'tag'      => 'Charging',
        'summary'  => 'Kabel harus ditekuk-tekuk agar tersambung, pengisian sangat lambat, atau tidak ada indikator masuk sama sekali.',
        'causes'   => 'Penumpukan serat kain di dalam lubang port, pin konektor aus/patah, atau IC charging lemah.',
        'tips'     => 'Coba ganti kabel dan adaptor lain terlebih dahulu. Jangan mencolok benda logam tajam ke dalam port.',
        'wa_text'  => 'Halo Reno Cell, HP saya tidak bisa dicas meskipun sudah ganti kabel. Mau minta tolong dicek konektornya.'
    ],
    [
        'id'       => 'mati-total',
        'icon'     => 'power-off',
        'title'    => 'HP Tidak Menyala',
        'tag'      => 'Power',
        'summary'  => 'HP sama sekali tidak merespons tombol power, tidak bergetar, dan layar tetap gelap pekat.',
        'causes'   => 'Baterai kehabisan daya total (deep discharge), tombol power rusak, atau jalur motherboard konslet.',
        'tips'     => 'Biarkan dicas dengan charger original minimal 30 menit tanpa diganggu sebelum mencoba menyalakan lagi.',
        'wa_text'  => 'Halo Reno Cell, HP saya mati total dan tidak bereaksi saat dicas. Mau konsultasi pemeriksaan awal.'
    ],
    [
        'id'       => 'speaker-rusak',
        'icon'     => 'volume-x',
        'title'    => 'Speaker Bermasalah',
        'tag'      => 'Audio',
        'summary'  => 'Suara musik sember/pecah, tidak terdengar saat telepon, atau suara kita tidak didengar lawan bicara.',
        'causes'   => 'Membran speaker sobek, lubang grille tersumbat debu, atau modul mic kemasukan cairan.',
        'tips'     => 'Periksa apakah ada kotoran kering di lubang speaker luar, bersihkan perlahan dengan kuas berbulu halus.',
        'wa_text'  => 'Halo Reno Cell, suara speaker telepon saya sangat kecil dan kresek-kresek. Mau tanya opsi perbaikannya.'
    ],
    [
        'id'       => 'hp-lemot',
        'icon'     => 'gauge',
        'title'    => 'HP Lemot / Hang',
        'tag'      => 'Software',
        'summary'  => 'Respon lambat saat buka aplikasi, sering freeze beberapa detik, atau muncul peringatan memori penuh terus-menerus.',
        'causes'   => 'Penyimpanan internal hampir 100% penuh, cache aplikasi menumpuk, atau sistem operasi butuh pembaruan/refresh.',
        'tips'     => 'Hapus aplikasi yang tidak dipakai dan kosongkan ruang minimal 10-15% dari total memori internal.',
        'wa_text'  => 'Halo Reno Cell, HP saya sering nge-freeze dan lambat sekali. Apakah ada layanan pembersihan sistem/software?'
    ],
    [
        'id'       => 'kamera-rusak',
        'icon'     => 'camera-off',
        'title'    => 'Kamera Bermasalah',
        'tag'      => 'Kamera',
        'summary'  => 'Hasil jepretan buram tidak bisa fokus, layar kamera bergetar/berisik mekanik, atau layar hitam saat buka kamera.',
        'causes'   => 'Motor Optical Image Stabilization (OIS) rusak (sering karena getaran motor/stang), atau lensa baret parah.',
        'tips'     => 'Cek apakah kaca luar bersih dari minyak tangan. Uji di aplikasi kamera bawaan dengan mode berbeda.',
        'wa_text'  => 'Halo Reno Cell, kamera belakang HP saya getar dan tidak bisa fokus. Mau konsultasi perbaikan modul kamera.'
    ]
];

/**
 * Pertanyaan Sering Ditanyakan (FAQ)
 */
$faqData = [
    [
        'question' => 'Berapa lama proses servis HP di Reno Cell?',
        'answer'   => 'Untuk perbaikan umum seperti penggantian baterai, LCD, atau port charger dengan suku cadang yang tersedia, proses pengerjaan rata-rata berkisar antara 45 hingga 90 menit (dapat ditunggu). Untuk kasus yang memerlukan penelusuran jalur seperti HP mati total atau kerusakan mesin (motherboard), estimasi waktu biasanya 1 hingga 3 hari kerja tergantung tingkat kerumitan.'
    ],
    [
        'question' => 'Apakah bisa konsultasi terlebih dahulu sebelum datang ke toko?',
        'answer'   => 'Tentu saja sangat bisa. Kami sangat menyarankan Anda menghubungi kami via WhatsApp terlebih dahulu untuk menceritakan gejala kerusakan, tipe HP, serta menanyakan ketersediaan suku cadang agar kunjungan Anda lebih efisien dan nyaman.'
    ],
    [
        'question' => 'Apakah harga dan estimasi biaya bisa diketahui terlebih dahulu?',
        'answer'   => 'Ya. Kami selalu menyampaikan perkiraan biaya di awal sebelum memulai pengerjaan. Jika saat pemeriksaan teknisi menemukan kerusakan tambahan yang mempengaruhi biaya, kami akan meminta persetujuan Anda terlebih dahulu. Tidak ada perbaikan yang dikerjakan tanpa persetujuan Anda.'
    ],
    [
        'question' => 'Apakah semua tipe smartphone dapat diperbaiki di Reno Cell?',
        'answer'   => 'Kami menangani berbagai merek populer seperti Apple (iPhone), Samsung, Xiaomi, Redmi, OPPO, vivo, hingga realme. Namun ketersediaan suku cadang untuk tipe smartphone keluaran lama atau model tertentu perlu kami konfirmasikan terlebih dahulu.'
    ],
    [
        'question' => 'Apakah ada garansi setelah servis selesai?',
        'answer'   => 'Setiap perbaikan di Reno Cell dilengkapi dengan garansi layanan dan spare part sesuai ketentuan yang disepakati saat pengerjaan (umumnya antara 14 hingga 90 hari tergantung jenis komponen dan penggantian). Garansi tidak berlaku untuk kelalaian pasca-servis seperti terkena air, jatuh, atau segel garansi rusak.'
    ],
    [
        'question' => 'Bagaimana menjaga keamanan data pribadi di HP saya?',
        'answer'   => 'Privasi pelanggan adalah prioritas kami. Untuk perbaikan hardware murni (seperti ganti layar, baterai, port cas), data di dalam HP biasanya tetap aman dan tidak diotak-atik. Namun demikian, kami selalu menyarankan pelanggan untuk melakukan backup data penting secara mandiri sebelum menyerahkan perangkat untuk pencegahan menyeluruh.'
    ],
    [
        'question' => 'Apakah harus membuat janji temu terlebih dahulu?',
        'answer'   => 'Anda bisa langsung datang ke workshop kami selama jam operasional buka. Meski demikian, membuat konfirmasi jadwal via WhatsApp sebelumnya akan membantu kami mempersiapkan spare part yang sesuai sehingga waktu tunggu Anda menjadi jauh lebih singkat.'
    ]
];

/**
 * Data Testimoni Demo (Sesuai instruksi: ditandai dengan jelas sebagai format ulasan/placeholder demo)
 */
$testimonialsDemo = [
    [
        'name'    => 'Pelanggan Demo A (Budi S.)',
        'device'  => 'Samsung Galaxy A52',
        'service' => 'Ganti Port Charger & Pembersihan Mic',
        'quote'   => 'Penjelasannya sangat jelas dan tidak dipaksa ganti macam-macam. Port charger diperiksa dulu ternyata hanya kotor dan pin-nya dibersihkan, biaya transparan sekali.',
        'badge'   => 'Contoh Format Ulasan'
    ],
    [
        'name'    => 'Pelanggan Demo B (Siti R.)',
        'device'  => 'iPhone 11',
        'service' => 'Penggantian Baterai Health 73%',
        'quote'   => 'Pelayanannya ramah dan tempatnya bersih. Pengerjaan baterai bisa ditunggu sekitar 40 menit, baterai baru awet dan ada garansinya.',
        'badge'   => 'Contoh Format Ulasan'
    ],
    [
        'name'    => 'Pelanggan Demo C (Dimas K.)',
        'device'  => 'Redmi Note 10 Pro',
        'service' => 'Ganti Modul Layar LCD',
        'quote'   => 'Layar pecah karena jatuh dari motor, teknisinya kasih tahu opsi grade layar yang ada dengan jelas. Hasil pasangnya rapi dan presisi.',
        'badge'   => 'Contoh Format Ulasan'
    ]
];
