<?php
/**
 * RENO CELL — HEADER & NAVIGATION
 * File: includes/header.php
 */
if (!isset($siteConfig)) {
    require_once __DIR__ . '/../config/site.php';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  
  <title><?php echo htmlspecialchars($siteConfig['brand_name']); ?> — <?php echo htmlspecialchars($siteConfig['tagline']); ?></title>
  <meta name="description" content="<?php echo htmlspecialchars($siteConfig['meta_description']); ?>">
  <meta name="theme-color" content="#647B61">
  <meta name="robots" content="index, follow">

  <!-- Open Graph Meta Tags -->
  <meta property="og:title" content="<?php echo htmlspecialchars($siteConfig['brand_name']); ?> — Smartphone Repair Service">
  <meta property="og:description" content="<?php echo htmlspecialchars($siteConfig['meta_description']); ?>">
  <meta property="og:type" content="website">

  <!-- Google Fonts: Plus Jakarta Sans -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

  <!-- Stylesheet Utama -->
  <link rel="stylesheet" href="assets/css/style.css">

  <!-- Lucide Icons Library (CDN dengan script tag) -->
  <script src="https://cdn.jsdelivr.net/npm/lucide@latest/dist/umd/lucide.min.js"></script>

  <!-- Favicon Sederhana (SVG) -->
  <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23647B61' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><rect width='14' height='20' x='5' y='2' rx='2' ry='2'/><path d='M12 18h.01'/></svg>">
</head>
<body>

  <!-- ========================================================================
       NAVBAR
       ======================================================================== -->
  <header class="navbar" id="main-navbar">
    <div class="container">
      <!-- Logo Reno Cell -->
      <a href="#beranda" class="nav-brand" aria-label="Beranda Reno Cell">
        <div class="brand-icon-box">
          <!-- Smartphone Icon -->
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <rect width="14" height="20" x="5" y="2" rx="2" ry="2"/>
            <path d="M12 18h.01"/>
          </svg>
        </div>
        <div class="brand-text">
          <span class="brand-title">Reno<span>Cell</span></span>
          <span class="brand-tag">Smartphone Repair</span>
        </div>
      </a>

      <!-- Desktop Nav Menu -->
      <nav class="nav-menu" aria-label="Menu Utama">
        <a href="#beranda" class="nav-link">Beranda</a>
        <a href="#layanan" class="nav-link">Layanan</a>
        <a href="#estimasi" class="nav-link">Estimasi Harga</a>
        <a href="#kendala" class="nav-link">Cek Kendala</a>
        <a href="#tentang" class="nav-link">Tentang Kami</a>
        <a href="#faq" class="nav-link">FAQ</a>
        <a href="#kontak" class="nav-link">Kontak</a>
      </nav>

      <!-- Desktop CTA -->
      <div class="nav-cta">
        <a href="<?php echo htmlspecialchars(get_whatsapp_url('Halo Reno Cell, saya ingin konsultasi mengenai kendala smartphone saya.')); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm">
          <!-- WhatsApp Icon -->
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
          Konsultasi WhatsApp
        </a>
      </div>

      <!-- Hamburger Button (Mobile) -->
      <button class="hamburger" id="hamburger-btn" aria-label="Buka Menu Navigasi" aria-expanded="false">
        <span></span>
        <span></span>
        <span></span>
      </button>
    </div>
  </header>

  <!-- Mobile Navigation Backdrop -->
  <div class="mobile-nav-backdrop" id="mobile-drawer-backdrop"></div>

  <!-- Mobile Navigation Drawer -->
  <aside class="mobile-nav-drawer" id="mobile-drawer" aria-label="Menu Seluler">
    <div class="mobile-menu-links">
      <a href="#beranda" class="mobile-menu-link">
        <span>Beranda</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>
      </a>
      <a href="#layanan" class="mobile-menu-link">
        <span>Layanan Servis</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>
      </a>
      <a href="#estimasi" class="mobile-menu-link">
        <span>Estimasi Biaya</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>
      </a>
      <a href="#kendala" class="mobile-menu-link">
        <span>Cek Kendala HP</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>
      </a>
      <a href="#tentang" class="mobile-menu-link">
        <span>Tentang Reno Cell</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>
      </a>
      <a href="#faq" class="mobile-menu-link">
        <span>Tanya Jawab (FAQ)</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>
      </a>
      <a href="#kontak" class="mobile-menu-link">
        <span>Kontak & Lokasi</span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg>
      </a>
    </div>

    <div class="mobile-drawer-footer">
      <a href="<?php echo htmlspecialchars(get_whatsapp_url()); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-block">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
        Chat WhatsApp
      </a>
      <p class="mobile-contact-note">
        <?php echo htmlspecialchars($siteConfig['hours_weekdays']); ?>
      </p>
    </div>
  </aside>
