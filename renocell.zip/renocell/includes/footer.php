<?php
/**
 * RENO CELL — FOOTER & FLOATING WIDGETS
 * File: includes/footer.php
 */
if (!isset($siteConfig)) {
    require_once __DIR__ . '/../config/site.php';
}
?>

  <!-- ========================================================================
       FOOTER
       ======================================================================== -->
  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        
        <!-- Kolom 1: Profil Reno Cell -->
        <div class="footer-col">
          <div class="footer-brand-title">
            <!-- Smartphone Icon -->
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
              <rect width="14" height="20" x="5" y="2" rx="2" ry="2"/>
              <path d="M12 18h.01"/>
            </svg>
            Reno<span>Cell</span>
          </div>
          <p class="footer-desc">
            Reno Cell hadir untuk membantu Anda mengatasi berbagai kendala smartphone dengan pendekatan yang ramah, penjelasan transparan, dan pengerjaan yang teliti.
          </p>
          <div class="badge-demo" style="background: rgba(255,255,255,0.08); border-color: rgba(255,255,255,0.15); color: #C2CCBF;">
            Independent Repair Service
          </div>
        </div>

        <!-- Kolom 2: Navigasi Website -->
        <div class="footer-col">
          <h4 class="footer-heading">Navigasi</h4>
          <ul class="footer-links-list">
            <li><a href="#beranda" class="footer-link">Beranda</a></li>
            <li><a href="#layanan" class="footer-link">Layanan Servis</a></li>
            <li><a href="#estimasi" class="footer-link">Estimasi Harga</a></li>
            <li><a href="#kendala" class="footer-link">Cek Gejala HP</a></li>
            <li><a href="#tentang" class="footer-link">Tentang Reno Cell</a></li>
            <li><a href="#faq" class="footer-link">Tanya Jawab (FAQ)</a></li>
            <li><a href="#kontak" class="footer-link">Kontak & Lokasi</a></li>
          </ul>
        </div>

        <!-- Kolom 3: Layanan Populer -->
        <div class="footer-col">
          <h4 class="footer-heading">Layanan Utama</h4>
          <ul class="footer-links-list">
            <li><a href="#layanan" class="footer-link">Ganti LCD & Touchscreen</a></li>
            <li><a href="#layanan" class="footer-link">Penggantian Baterai</a></li>
            <li><a href="#layanan" class="footer-link">Perbaikan Port Charger</a></li>
            <li><a href="#layanan" class="footer-link">Kamera & Lensa</a></li>
            <li><a href="#layanan" class="footer-link">Speaker & Mikrofon</a></li>
            <li><a href="#layanan" class="footer-link">Pemeriksaan HP Mati Total</a></li>
            <li><a href="#layanan" class="footer-link">Software & Bootloop</a></li>
          </ul>
        </div>

        <!-- Kolom 4: Informasi Kontak & Jam Buka -->
        <div class="footer-col">
          <h4 class="footer-heading">Kontak & Jadwal</h4>
          <ul class="footer-links-list">
            <li class="footer-link" style="display: flex; gap: 8px;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0; margin-top:3px;"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
              <span><?php echo htmlspecialchars($siteConfig['whatsapp_display']); ?></span>
            </li>
            <li class="footer-link" style="display: flex; gap: 8px;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0; margin-top:3px;"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
              <span><?php echo htmlspecialchars($siteConfig['address_street']); ?>, <?php echo htmlspecialchars($siteConfig['address_city']); ?></span>
            </li>
            <li class="footer-link" style="display: flex; gap: 8px;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0; margin-top:3px;"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              <span><?php echo htmlspecialchars($siteConfig['hours_weekdays']); ?></span>
            </li>
          </ul>

          <!-- Social Links Placeholder -->
          <div class="footer-social-links">
            <a href="<?php echo htmlspecialchars($siteConfig['socials']['instagram']); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn" aria-label="Instagram Reno Cell Demo">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>
            </a>
            <a href="<?php echo htmlspecialchars($siteConfig['socials']['tiktok']); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn" aria-label="TikTok Reno Cell Demo">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"/></svg>
            </a>
            <a href="<?php echo htmlspecialchars($siteConfig['socials']['facebook']); ?>" target="_blank" rel="noopener noreferrer" class="footer-social-btn" aria-label="Facebook Reno Cell Demo">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
            </a>
          </div>
        </div>

      </div>

      <!-- Footer Bottom -->
      <div class="footer-bottom">
        <p>© <?php echo date('Y'); ?> <?php echo htmlspecialchars($siteConfig['brand_name']); ?>. Hak cipta dilindungi undang-undang.</p>
        <p class="footer-disclaimer-note">
          Reno Cell adalah unit layanan servis perbaikan mandiri. Semua nama merek, logo, dan model smartphone yang ditampilkan merupakan hak milik dari masing-masing pemegang merek dan digunakan semata-mata untuk tujuan identifikasi kompatibilitas layanan.
        </p>
      </div>
    </div>
  </footer>

  <!-- ========================================================================
       FLOATING WIDGETS (WHATSAPP & CHATBOT LAUNCHER)
       ======================================================================== -->
  <div class="floating-widgets-container">
    
    <!-- Chatbot Launcher Button -->
    <button class="floating-chat-launcher" id="chat-launcher-btn" data-phone="<?php echo htmlspecialchars($siteConfig['whatsapp_number']); ?>" aria-label="Buka Reno Cell Assistant">
      <div class="chat-launcher-avatar">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
          <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v5Z"/>
          <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1"/>
        </svg>
        <span class="chat-status-dot"></span>
      </div>
      <div class="chat-launcher-text">
        <span class="chat-launcher-name">Reno Cell Assistant</span>
        <span class="chat-launcher-sub">Tanya & Cek Layanan</span>
      </div>
    </button>

    <!-- Floating WhatsApp Button -->
    <a href="<?php echo htmlspecialchars(get_whatsapp_url('Halo Reno Cell, saya ingin berkonsultasi mengenai servis HP saya.')); ?>" target="_blank" rel="noopener noreferrer" class="floating-wa-btn" aria-label="Chat WhatsApp Reno Cell">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
      </svg>
      <span class="wa-pulse-indicator"></span>
      <span class="wa-tooltip">Chat dengan Reno Cell</span>
    </a>

  </div>

  <!-- ========================================================================
       CHATBOT MODAL PANEL (RENO CELL ASSISTANT)
       ======================================================================== -->
  <div class="chatbot-modal-panel" id="chatbot-modal-panel" role="dialog" aria-modal="true" aria-label="Reno Cell Assistant Chatbot">
    <!-- Header Chatbot -->
    <div class="chatbot-header">
      <div class="chatbot-header-info">
        <div class="chatbot-avatar">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <rect width="14" height="20" x="5" y="2" rx="2" ry="2"/>
            <path d="M12 18h.01"/>
          </svg>
        </div>
        <div class="chatbot-header-titles">
          <span class="chatbot-title">Reno Cell Assistant</span>
          <span class="chatbot-status">
            <span class="chatbot-status-dot"></span> Online • CS Front-End Demo
          </span>
        </div>
      </div>
      <button class="chatbot-close-btn" id="chatbot-close-btn" aria-label="Tutup Percakapan">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>

    <!-- Messages Container -->
    <div class="chatbot-messages-body" id="chatbot-messages-body">
      <!-- Pesan Awal Sambutan -->
      <div class="chat-bubble bot">
        <div class="chat-bubble-content">
          Halo! Ada yang bisa kami bantu terkait servis smartphone Anda? Silakan pilih opsi cepat di bawah atau ketik kendala Anda secara langsung.
        </div>
        <div class="chat-time"><?php echo date('H:i'); ?></div>
      </div>
    </div>

    <!-- Quick Replies Chips -->
    <div class="chatbot-quick-replies" id="chatbot-quick-replies">
      <button type="button" class="quick-reply-btn">Lihat Layanan</button>
      <button type="button" class="quick-reply-btn">Cek Estimasi Harga</button>
      <button type="button" class="quick-reply-btn">Konsultasi Kerusakan</button>
      <button type="button" class="quick-reply-btn">Hubungi WhatsApp</button>
    </div>

    <!-- Input Box -->
    <div class="chatbot-input-box">
      <input type="text" id="chatbot-input-field" class="chatbot-input-field" placeholder="Ketik pertanyaan (cth: ganti baterai, lcd, alamat)..." autocomplete="off">
      <button type="button" id="chatbot-send-btn" class="chatbot-send-btn" aria-label="Kirim Pesan">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="22" y1="2" x2="11" y2="13"></line>
          <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
        </svg>
      </button>
    </div>
  </div>

  <!-- JavaScript Files -->
  <script src="assets/js/estimator.js"></script>
  <script src="assets/js/chatbot.js"></script>
  <script src="assets/js/main.js"></script>
</body>
</html>
