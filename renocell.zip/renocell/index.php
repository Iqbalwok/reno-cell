<?php
/**
 * RENO CELL — LANDING PAGE UTAMA
 * File: index.php
 */
require_once __DIR__ . '/config/site.php';
require_once __DIR__ . '/includes/header.php';
?>

  <!-- ========================================================================
       SECTION B: HERO SECTION
       ======================================================================== -->
  <section class="hero-section" id="beranda">
    <div class="container">
      <div class="hero-grid">
        
        <!-- Kolom Kiri: Informasi & Ajakan -->
        <div class="hero-content reveal">
          <div class="hero-tag">
            <span class="hero-tag-dot"></span>
            Solusi Servis Smartphone
          </div>

          <h1 class="hero-title">
            HP Bermasalah?<br>
            <span>Kami Siap Membantu.</span>
          </h1>

          <p class="hero-desc">
            Reno Cell membantu Anda mengatasi berbagai masalah smartphone dengan pelayanan yang ramah, penjelasan yang jelas, dan proses servis yang nyaman.
          </p>

          <div class="hero-actions">
            <a href="<?php echo htmlspecialchars(get_whatsapp_url('Halo Reno Cell, HP saya bermasalah dan saya ingin konsultasi awal.')); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-lg">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
              </svg>
              Konsultasi via WhatsApp
            </a>

            <a href="#layanan" class="btn btn-secondary btn-lg">
              Lihat Layanan
            </a>
          </div>

          <!-- Tiga Nilai Singkat Sesuai Spesifikasi -->
          <div class="hero-features">
            <div class="feature-pill">
              <span class="feature-pill-icon">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
              </span>
              <span>Konsultasi Mudah</span>
            </div>

            <div class="feature-pill">
              <span class="feature-pill-icon">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
              </span>
              <span>Estimasi Biaya Transparan</span>
            </div>

            <div class="feature-pill">
              <span class="feature-pill-icon">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
              </span>
              <span>Pelayanan Ramah</span>
            </div>
          </div>
        </div>

        <!-- Kolom Kanan: Foto Realistis Teknisi & Meja Servis -->
        <div class="hero-visual reveal reveal-delay-2">
          <div class="hero-image-wrapper">
            <img src="assets/images/hero-repair.jpg" alt="Teknisi Reno Cell sedang memperbaiki smartphone di meja servis yang bersih dan rapi" width="600" height="480" loading="eager">
          </div>

          <!-- Floating Badges Natural -->
          <div class="hero-float-card top-right">
            <div class="hero-float-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            </div>
            <div>
              <p class="hero-float-label">Standar Kerja</p>
              <h4 class="hero-float-title">Pemeriksaan Transparan</h4>
            </div>
          </div>

          <div class="hero-float-card bottom-left">
            <div class="hero-float-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
            </div>
            <div>
              <p class="hero-float-label">Peralatan Presisi</p>
              <h4 class="hero-float-title">Teknisi Teliti</h4>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ========================================================================
       SECTION C: TRUST SECTION (BAR 4 POIN)
       ======================================================================== -->
  <section class="trust-section">
    <div class="container">
      <div class="trust-bar reveal">
        
        <!-- Poin 1 -->
        <div class="trust-item">
          <div class="trust-icon-box">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </div>
          <div class="trust-content">
            <h4 class="trust-item-title">1. Pemeriksaan Awal</h4>
            <p class="trust-item-desc">Pengecekan fisik dan fungsi sebelum dibongkar.</p>
          </div>
        </div>

        <!-- Poin 2 -->
        <div class="trust-item">
          <div class="trust-icon-box">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="2" y="4" width="20" height="16" rx="2"/>
              <line x1="6" y1="12" x2="18" y2="12"/>
            </svg>
          </div>
          <div class="trust-content">
            <h4 class="trust-item-title">2. Estimasi Biaya</h4>
            <p class="trust-item-desc">Disampaikan terbuka sebelum pengerjaan dimulai.</p>
          </div>
        </div>

        <!-- Poin 3 -->
        <div class="trust-item">
          <div class="trust-icon-box">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg>
          </div>
          <div class="trust-content">
            <h4 class="trust-item-title">3. Konsultasi Mudah</h4>
            <p class="trust-item-desc">Tanya jawab ramah via WhatsApp atau langsung ke toko.</p>
          </div>
        </div>

        <!-- Poin 4 -->
        <div class="trust-item">
          <div class="trust-icon-box">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <path d="m9 12 2 2 4-4"/>
            </svg>
          </div>
          <div class="trust-content">
            <h4 class="trust-item-title">4. Informasi Garansi</h4>
            <p class="trust-item-desc">Garansi layanan dan suku cadang sesuai ketentuan.</p>
          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- ========================================================================
       SECTION D: LAYANAN SERVIS
       ======================================================================== -->
  <section class="services-section" id="layanan">
    <div class="container">
      <div class="section-header reveal">
        <span class="section-tag">Pilihan Solusi</span>
        <h2 class="section-title">Layanan Perbaikan Smartphone</h2>
        <p class="section-description">
          Berbagai solusi untuk membantu mengatasi kendala smartphone Anda dengan peralatan servis yang memadai dan penanganan yang cermat.
        </p>
      </div>

      <!-- Grid 8 Kartu Layanan -->
      <div class="services-grid">
        <?php foreach ($servicesData as $index => $service): ?>
          <div class="service-card reveal reveal-delay-<?php echo ($index % 4) + 1; ?>">
            <div class="service-image-box">
              <img src="<?php echo htmlspecialchars($service['image']); ?>" alt="<?php echo htmlspecialchars($service['title']); ?>" loading="lazy">
              <span class="service-tag"><?php echo htmlspecialchars($service['category']); ?></span>
            </div>
            
            <div class="service-body">
              <h3 class="service-title"><?php echo htmlspecialchars($service['title']); ?></h3>
              <p class="service-desc"><?php echo htmlspecialchars($service['description']); ?></p>
              
              <div class="service-footer">
                <span class="service-duration">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                  <?php echo htmlspecialchars($service['duration']); ?>
                </span>

                <a href="<?php echo htmlspecialchars(get_whatsapp_url($service['wa_intent'])); ?>" target="_blank" rel="noopener noreferrer" class="service-cta-link" aria-label="Konsultasi <?php echo htmlspecialchars($service['title']); ?>">
                  <span>Konsultasi</span>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                </a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Catatan Ketersediaan Sparepart Sesuai Ketentuan -->
      <p class="services-note reveal">
        <strong>Catatan:</strong> Ketersediaan perbaikan dan komponen suku cadang bergantung pada hasil pemeriksaan fisik teknisi serta ketersediaan stok komponen tipe perangkat Anda.
      </p>

      <div class="services-action reveal">
        <a href="<?php echo htmlspecialchars(get_whatsapp_url('Halo Reno Cell, saya ingin menanyakan layanan perbaikan smartphone untuk tipe HP saya.')); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-secondary">
          Lihat Semua Layanan & Tanya Tipe HP
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
        </a>
      </div>

    </div>
  </section>

  <!-- ========================================================================
       SECTION E: BRAND SMARTPHONE
       ======================================================================== -->
  <section class="brands-section">
    <div class="container">
      <div class="section-header reveal" style="margin-bottom: 30px;">
        <span class="section-tag">Kompatibilitas</span>
        <h2 class="section-title">Melayani Berbagai Merek Smartphone</h2>
        <p class="section-description">
          Kami menangani perbaikan komponen berbagai merek smartphone yang umum digunakan di Indonesia.
        </p>
      </div>

      <!-- Wordmark Brand Badges -->
      <div class="brands-container reveal">
        <?php foreach ($brandsData as $brand): ?>
          <div class="brand-badge">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color: var(--color-olive);">
              <rect width="14" height="20" x="5" y="2" rx="2" ry="2"/>
              <path d="M12 18h.01"/>
            </svg>
            <span><?php echo htmlspecialchars($brand['name']); ?></span>
            <span class="brand-subtext"><?php echo htmlspecialchars($brand['badge']); ?></span>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Disclaimer Resmi Tanpa Mengklaim Service Center Resmi -->
      <p class="brands-disclaimer reveal">
        *Reno Cell adalah penyedia jasa perbaikan independen dan bukan service center resmi dari merek yang disebutkan. Semua merek dagang dan logo merupakan hak milik produsen masing-masing. Ketersediaan spare part untuk tiap seri perlu dikonfirmasikan terlebih dahulu.
      </p>
    </div>
  </section>

  <!-- ========================================================================
       SECTION F: KEUNGGULAN RENO CELL
       ======================================================================== -->
  <section class="advantages-section">
    <div class="container">
      <div class="section-header reveal">
        <span class="section-tag">Kenyamanan Anda</span>
        <h2 class="section-title">Kenapa Memilih Reno Cell?</h2>
        <p class="section-description">
          Kami mengutamakan kejujuran informasi dan kenyamanan Anda selama proses penanganan smartphone.
        </p>
      </div>

      <!-- Grid 4 Keunggulan (Tanpa Statistik Palsu) -->
      <div class="advantages-grid">
        
        <div class="advantage-card reveal reveal-delay-1">
          <div class="advantage-icon-wrapper">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/>
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>
            </svg>
          </div>
          <h3 class="advantage-title">Penjelasan yang Mudah Dipahami</h3>
          <p class="advantage-desc">
            Teknisi kami menjelaskan kendala perangkat Anda dengan bahasa yang sederhana dan santai, tanpa istilah teknis yang membingungkan.
          </p>
        </div>

        <div class="advantage-card reveal reveal-delay-2">
          <div class="advantage-icon-wrapper">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="12" y1="1" x2="12" y2="23"/>
              <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
            </svg>
          </div>
          <h3 class="advantage-title">Estimasi Biaya Sebelum Pengerjaan</h3>
          <p class="advantage-desc">
            Biaya selalu kami komunikasikan sebelum perbaikan dilakukan. Tidak ada tagihan tak terduga yang muncul tanpa persetujuan Anda.
          </p>
        </div>

        <div class="advantage-card reveal reveal-delay-3">
          <div class="advantage-icon-wrapper">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
            </svg>
          </div>
          <h3 class="advantage-title">Konsultasi yang Praktis</h3>
          <p class="advantage-desc">
            Anda dapat menceritakan kendala terlebih dahulu melalui chat WhatsApp untuk menanyakan stok part atau estimasi durasi sebelum datang.
          </p>
        </div>

        <div class="advantage-card reveal reveal-delay-4">
          <div class="advantage-icon-wrapper">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              <circle cx="12" cy="11" r="3"/>
            </svg>
          </div>
          <h3 class="advantage-title">Proses Servis yang Transparan</h3>
          <p class="advantage-desc">
            Kondisi komponen lama yang diganti akan diperlihatkan kepada Anda sebagai wujud tanggung jawab dan keterbukaan layanan kami.
          </p>
        </div>

      </div>
    </div>
  </section>

  <!-- ========================================================================
       SECTION G: TAHAPAN SERVIS
       ======================================================================== -->
  <section class="process-section">
    <div class="container">
      <div class="section-header reveal">
        <span class="section-tag">Alur Kerja</span>
        <h2 class="section-title">Proses Servis yang Mudah</h2>
        <p class="section-description">
          Empat tahapan sederhana dari awal konsultasi hingga smartphone Anda selesai diperbaiki.
        </p>
      </div>

      <div class="process-grid">
        <!-- Garis Penghubung Desktop -->
        <div class="process-connector-line"></div>

        <!-- Tahap 1 -->
        <div class="process-step-card reveal reveal-delay-1">
          <div class="step-num-badge">01</div>
          <h3 class="step-title">Konsultasi</h3>
          <p class="step-desc">Ceritakan kendala yang Anda alami pada smartphone secara online via WhatsApp atau langsung ke toko kami.</p>
        </div>

        <!-- Tahap 2 -->
        <div class="process-step-card reveal reveal-delay-2">
          <div class="step-num-badge">02</div>
          <h3 class="step-title">Pemeriksaan</h3>
          <p class="step-desc">Perangkat diperiksa secara menyeluruh oleh teknisi untuk mengetahui sumber kerusakan secara tepat.</p>
        </div>

        <!-- Tahap 3 -->
        <div class="process-step-card reveal reveal-delay-3">
          <div class="step-num-badge">03</div>
          <h3 class="step-title">Persetujuan</h3>
          <p class="step-desc">Estimasi biaya dan pilihan suku cadang disampaikan. Pengerjaan baru dimulai setelah Anda setuju.</p>
        </div>

        <!-- Tahap 4 -->
        <div class="process-step-card reveal reveal-delay-4">
          <div class="step-num-badge">04</div>
          <h3 class="step-title">Perbaikan</h3>
          <p class="step-desc">Servis dilakukan dengan rapi, diuji fungsi finalnya, dan disertai garansi sesuai kesepakatan.</p>
        </div>

      </div>
    </div>
  </section>

  <!-- ========================================================================
       SECTION H: ESTIMASI HARGA (INTERACTIVE TOOL)
       ======================================================================== -->
  <section class="estimator-section" id="estimasi">
    <div class="container">
      <div class="section-header reveal">
        <span class="section-tag">Simulasi Biaya</span>
        <h2 class="section-title">Estimasi Biaya Servis</h2>
        <p class="section-description">
          Temukan perkiraan biaya berdasarkan jenis kerusakan smartphone Anda dengan alat simulasi interaktif di bawah ini.
        </p>
      </div>

      <!-- Estimator Box -->
      <div class="estimator-box reveal">
        <div class="estimator-layout">
          
          <!-- Sisi Kiri: Form Interaktif -->
          <div class="estimator-form">
            <div class="form-group">
              <label for="est-brand" class="form-label">
                <span>1. Pilih Merek Smartphone</span>
                <span class="badge-demo">Demo Input</span>
              </label>
              <select id="est-brand" class="form-select">
                <option value="apple">Apple / iPhone</option>
                <option value="samsung" selected>Samsung</option>
                <option value="xiaomi">Xiaomi</option>
                <option value="redmi">Redmi</option>
                <option value="oppo">OPPO</option>
                <option value="vivo">vivo</option>
                <option value="realme">realme</option>
              </select>
            </div>

            <div class="form-group">
              <label for="est-model" class="form-label">
                <span>2. Pilih Seri / Model</span>
              </label>
              <select id="est-model" class="form-select">
                <!-- Diisi otomatis oleh estimator.js -->
              </select>
            </div>

            <div class="form-group">
              <label for="est-damage" class="form-label">
                <span>3. Pilih Jenis Kerusakan</span>
              </label>
              <select id="est-damage" class="form-select">
                <option value="lcd">Ganti Layar LCD & Touchscreen</option>
                <option value="baterai" selected>Penggantian Baterai Baru</option>
                <option value="charger">Port Charger / Masalah Pengisian</option>
                <option value="kamera">Kamera Depan / Belakang</option>
                <option value="speaker">Speaker Panggilan / Musik</option>
                <option value="tombol">Tombol Power / Volume</option>
                <option value="mesin">Pemeriksaan HP Mati Total</option>
              </select>
            </div>
          </div>

          <!-- Sisi Kanan: Kartu Hasil Estimasi -->
          <div class="estimator-result-card">
            <div>
              <div class="result-card-header">
                <span class="result-title">Hasil Simulasi Estimasi</span>
                <span class="badge-demo">Contoh Perkiraan</span>
              </div>

              <!-- Price Box -->
              <div class="price-display-wrapper">
                <p class="price-subtext">Rentang Perkiraan Biaya:</p>
                <div class="price-value" id="est-price-value">Rp 180.000 – Rp 350.000*</div>
              </div>

              <!-- Meta List -->
              <div class="result-meta-list">
                <div class="meta-row">
                  <span class="meta-label">Estimasi Durasi:</span>
                  <span class="meta-value" id="est-duration-value">30 - 60 Menit</span>
                </div>
                <div class="meta-row">
                  <span class="meta-label">Ketentuan Garansi:</span>
                  <span class="meta-value" id="est-warranty-value">Garansi 30 Hari</span>
                </div>
              </div>

              <!-- Catatan Penting Sesuai Spesifikasi -->
              <p class="estimator-disclaimer">
                <strong>Catatan Penting:</strong> Seluruh harga di atas merupakan <em>data simulasi contoh</em>. Biaya final ditentukan secara akurat setelah teknisi memeriksa langsung kondisi fisik dan tipe suku cadang yang dibutuhkan di toko.
              </p>
            </div>

            <!-- Tombol Tanya via WhatsApp -->
            <a href="#" id="est-wa-btn" data-phone="<?php echo htmlspecialchars($siteConfig['whatsapp_number']); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-block">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
              Tanyakan via WhatsApp
            </a>
          </div>

        </div>
      </div>
    </div>
  </section>

  <!-- ========================================================================
       SECTION I: CEK KENDALA HP (INTERACTIVE SYMPTOM CHECKER)
       ======================================================================== -->
  <section class="symptom-section" id="kendala">
    <div class="container">
      <div class="section-header reveal">
        <span class="section-tag">Gejala & Kerusakan</span>
        <h2 class="section-title">Apa Masalah pada HP Anda?</h2>
        <p class="section-description">
          Pilih keluhan yang sedang dialami perangkat Anda untuk membaca penjelasan awal dan langkah penanganan yang dianjurkan.
        </p>
      </div>

      <!-- Kartu Pilihan Gejala (7 Gejala) -->
      <div class="symptom-chips-grid reveal">
        <?php foreach ($symptomsData as $idx => $symptom): ?>
          <div class="symptom-chip-card <?php echo $idx === 0 ? 'active' : ''; ?>"
               data-id="<?php echo htmlspecialchars($symptom['id']); ?>"
               data-title="<?php echo htmlspecialchars($symptom['title']); ?>"
               data-tag="<?php echo htmlspecialchars($symptom['tag']); ?>"
               data-summary="<?php echo htmlspecialchars($symptom['summary']); ?>"
               data-causes="<?php echo htmlspecialchars($symptom['causes']); ?>"
               data-tips="<?php echo htmlspecialchars($symptom['tips']); ?>"
               data-wa="<?php echo htmlspecialchars($symptom['wa_text']); ?>">
            <div class="symptom-chip-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect width="14" height="20" x="5" y="2" rx="2" ry="2"/>
                <path d="M12 18h.01"/>
              </svg>
            </div>
            <div>
              <h4 class="symptom-chip-name"><?php echo htmlspecialchars($symptom['title']); ?></h4>
              <span class="symptom-chip-tag"><?php echo htmlspecialchars($symptom['tag']); ?></span>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Detail Penjelasan Interaktif -->
      <div class="symptom-detail-panel reveal" id="symptom-detail-panel">
        <div class="symptom-detail-header">
          <div class="symptom-detail-title-group">
            <span class="section-tag symptom-detail-tag" style="margin-bottom:0;">
              <?php echo htmlspecialchars($symptomsData[0]['tag']); ?>
            </span>
            <h3 class="symptom-detail-title">
              <?php echo htmlspecialchars($symptomsData[0]['title']); ?>
            </h3>
          </div>
          <span class="badge-demo">Penjelasan Edukatif</span>
        </div>

        <p class="symptom-detail-summary" style="font-size: 0.95rem; color: var(--color-charcoal); margin-bottom: 22px;">
          <?php echo htmlspecialchars($symptomsData[0]['summary']); ?>
        </p>

        <div class="symptom-detail-grid">
          <!-- Blok Kemungkinan Penyebab -->
          <div class="detail-block">
            <h4 class="detail-block-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              Kemungkinan Penyebab Awal:
            </h4>
            <p class="detail-block-text symptom-detail-causes">
              <?php echo htmlspecialchars($symptomsData[0]['causes']); ?>
            </p>
          </div>

          <!-- Blok Langkah Mandiri yang Aman -->
          <div class="detail-block">
            <h4 class="detail-block-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
              Langkah Awal yang Aman:
            </h4>
            <p class="detail-block-text symptom-detail-tips">
              <?php echo htmlspecialchars($symptomsData[0]['tips']); ?>
            </p>
          </div>
        </div>

        <!-- Action & Disclaimer -->
        <div class="symptom-detail-action">
          <p class="symptom-disclaimer">
            *Catatan: Penjelasan di atas adalah referensi awal dan bukan vonis perbaikan mutlak. Pemeriksaan fisik teknisi diperlukan untuk diagnosa yang akurat.
          </p>

          <a href="<?php echo htmlspecialchars(get_whatsapp_url($symptomsData[0]['wa_text'])); ?>" 
             data-phone="<?php echo htmlspecialchars($siteConfig['whatsapp_number']); ?>"
             target="_blank" rel="noopener noreferrer" class="btn btn-primary symptom-consult-btn">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
            Konsultasikan Kendala Ini via WhatsApp
          </a>
        </div>
      </div>

    </div>
  </section>

  <!-- ========================================================================
       SECTION J: TENTANG RENO CELL
       ======================================================================== -->
  <section class="about-section" id="tentang">
    <div class="container">
      <div class="about-grid">
        
        <!-- Kolom Visual Meja & Tempat Servis -->
        <div class="about-visual reveal">
          <div class="about-image-card">
            <img src="assets/images/about-store.jpg" alt="Suasana meja perbaikan dan perlengkapan servis Reno Cell" width="560" height="440" loading="lazy">
          </div>
          
          <div class="about-info-overlay">
            <p class="about-info-title">Area Servis Nyaman</p>
            <p class="about-info-desc">Perlengkapan rapi dan pencahayaan memadai untuk ketelitian servis.</p>
          </div>
        </div>

        <!-- Kolom Teks Cerita Reno Cell Sesuai Instruksi -->
        <div class="about-content reveal reveal-delay-2">
          <span class="section-tag">Mengenal Kami</span>
          <h2 class="section-title">Tentang Reno Cell</h2>
          
          <p class="about-text">
            Reno Cell hadir untuk membantu pelanggan mengatasi berbagai kendala smartphone melalui layanan konsultasi yang mudah, penjelasan yang jelas, dan perhatian terhadap kebutuhan setiap perangkat.
          </p>

          <!-- Area Detail Tempat & Jam Operasional Placeholder -->
          <div class="about-details-list">
            
            <div class="about-detail-item">
              <div class="about-icon-box">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
              </div>
              <div class="about-detail-text">
                <h4>Alamat Workshop</h4>
                <p><?php echo htmlspecialchars($siteConfig['address_street']); ?>, <?php echo htmlspecialchars($siteConfig['address_city']); ?></p>
              </div>
            </div>

            <div class="about-detail-item">
              <div class="about-icon-box">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              </div>
              <div class="about-detail-text">
                <h4>Jam Operasional</h4>
                <p><?php echo htmlspecialchars($siteConfig['hours_weekdays']); ?> | <?php echo htmlspecialchars($siteConfig['hours_sunday']); ?></p>
              </div>
            </div>

            <div class="about-detail-item">
              <div class="about-icon-box">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
              </div>
              <div class="about-detail-text">
                <h4>Fokus Kami</h4>
                <p>Kepuasan pelanggan, kejujuran diagnosa, dan penanganan yang bertanggung jawab terhadap setiap unit HP.</p>
              </div>
            </div>

          </div>

          <a href="<?php echo htmlspecialchars(get_whatsapp_url('Halo Reno Cell, saya ingin menanyakan rute menuju workshop servis Anda.')); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-primary">
            Hubungi Workshop Kami
          </a>
        </div>

      </div>
    </div>
  </section>

  <!-- ========================================================================
       SECTION K: TESTIMONIAL (FORMAT CONTOH DEMO)
       ======================================================================== -->
  <section class="testimonials-section">
    <div class="container">
      <div class="section-header reveal">
        <span class="section-tag">Pengalaman Pelanggan</span>
        <h2 class="section-title">Cerita Pelanggan</h2>
        <p class="section-description">
          Berikut adalah format ulasan pelanggan yang disiapkan untuk menampung feedback asli dari para pelanggan Reno Cell.
        </p>
      </div>

      <!-- Grid Testimoni dengan Label Demo Terbuka -->
      <div class="testimonials-grid">
        <?php foreach ($testimonialsDemo as $t): ?>
          <div class="testimonial-card reveal">
            <div>
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
                <span class="badge-demo"><?php echo htmlspecialchars($t['badge']); ?></span>
                <span style="font-size: 0.72rem; color: var(--color-olive); font-weight: 600;">Verifikasi Layanan</span>
              </div>
              <p class="testimonial-quote">“<?php echo htmlspecialchars($t['quote']); ?>”</p>
            </div>

            <div class="testimonial-author-box">
              <div class="author-info">
                <h4><?php echo htmlspecialchars($t['name']); ?></h4>
                <p><?php echo htmlspecialchars($t['device']); ?> • <?php echo htmlspecialchars($t['service']); ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div style="text-align: center;" class="reveal">
        <p style="font-size: 0.75rem; color: var(--color-secondary);">
          *Kartu testimoni di atas merupakan format template yang siap diisi dengan review pelanggan resmi saat operasional berlangsung.
        </p>
      </div>
    </div>
  </section>

  <!-- ========================================================================
       SECTION L: FAQ ACCORDION (7 PERTANYAAN RESMI)
       ======================================================================== -->
  <section class="faq-section" id="faq">
    <div class="container">
      <div class="section-header reveal">
        <span class="section-tag">Bantuan Informasi</span>
        <h2 class="section-title">Pertanyaan yang Sering Diajukan</h2>
        <p class="section-description">
          Jawaban praktis untuk beberapa pertanyaan yang paling sering ditanyakan oleh pelanggan sebelum melakukan perbaikan smartphone.
        </p>
      </div>

      <!-- Accordion List -->
      <div class="faq-accordion reveal">
        <?php foreach ($faqData as $index => $faq): ?>
          <div class="faq-item">
            <button class="faq-trigger" type="button" aria-expanded="false">
              <span><?php echo htmlspecialchars($faq['question']); ?></span>
              <span class="faq-icon-chevron">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="m6 9 6 6 6-6"/></svg>
              </span>
            </button>
            <div class="faq-content">
              <div class="faq-body">
                <?php echo htmlspecialchars($faq['answer']); ?>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div style="text-align: center; margin-top: 36px;" class="reveal">
        <p style="font-size: var(--font-size-sm); color: var(--color-secondary); margin-bottom: 12px;">
          Punya pertanyaan lain yang belum tercantum di atas?
        </p>
        <a href="<?php echo htmlspecialchars(get_whatsapp_url('Halo Reno Cell, saya ada pertanyaan yang ingin saya konsultasikan.')); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sage btn-sm">
          Tanyakan Langsung ke WhatsApp
        </a>
      </div>

    </div>
  </section>

  <!-- ========================================================================
       SECTION M: KONTAK & SIMULASI FORM
       ======================================================================== -->
  <section class="contact-section" id="kontak">
    <div class="container">
      <div class="section-header reveal">
        <span class="section-tag">Hubungi Kami</span>
        <h2 class="section-title">Ada Kendala dengan HP Anda?</h2>
        <p class="section-description">
          Jangan ragu untuk menghubungi Reno Cell. Ceritakan kendala smartphone Anda dan kami akan membantu memberikan informasi awal.
        </p>
      </div>

      <div class="contact-grid">
        
        <!-- Sisi Kiri: Informasi Kontak & Lokasi -->
        <div class="contact-info-panel reveal">
          <div class="contact-card-list">
            
            <!-- WhatsApp -->
            <div class="contact-card">
              <div class="contact-card-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
              </div>
              <div>
                <p class="contact-card-title">Nomor WhatsApp</p>
                <p class="contact-card-detail"><?php echo htmlspecialchars($siteConfig['whatsapp_display']); ?></p>
              </div>
            </div>

            <!-- Alamat -->
            <div class="contact-card">
              <div class="contact-card-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
              </div>
              <div>
                <p class="contact-card-title">Alamat Toko</p>
                <p class="contact-card-detail"><?php echo htmlspecialchars($siteConfig['address_street']); ?><br><?php echo htmlspecialchars($siteConfig['address_city']); ?></p>
              </div>
            </div>

            <!-- Jam Buka -->
            <div class="contact-card">
              <div class="contact-card-icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              </div>
              <div>
                <p class="contact-card-title">Jam Operasional</p>
                <p class="contact-card-detail"><?php echo htmlspecialchars($siteConfig['hours_weekdays']); ?><br><?php echo htmlspecialchars($siteConfig['hours_sunday']); ?></p>
              </div>
            </div>

          </div>

          <!-- Area Google Maps Placeholder -->
          <div class="map-container">
            <div class="map-preview-box">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                <polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/>
                <line x1="9" y1="3" x2="9" y2="18"/>
                <line x1="15" y1="6" x2="15" y2="21"/>
              </svg>
              <span style="font-size: 0.85rem; font-weight: 700;">Area Peta Google Maps</span>
              <span class="map-note">Dapat diintegrasikan dengan Google Maps embed resmi lokasi toko Anda</span>
            </div>
            <a href="<?php echo htmlspecialchars($siteConfig['google_maps_url']); ?>" target="_blank" rel="noopener noreferrer" class="btn btn-sage btn-sm btn-block">
              Buka di Google Maps
            </a>
          </div>
        </div>

        <!-- Sisi Kanan: Form Kontak Front-End (Simulasi Interaktif) -->
        <div class="contact-form-panel reveal reveal-delay-2">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <h3 class="contact-form-title">Kirim Pesan Konsultasi</h3>
            <span class="badge-demo">Form Front-End Demo</span>
          </div>
          <p class="contact-form-subtitle">
            Isi formulir di bawah ini untuk konsultasi awal seputar kerusakan smartphone Anda.
          </p>

          <form id="front-contact-form" data-target-phone="<?php echo htmlspecialchars($siteConfig['whatsapp_number']); ?>">
            <div class="form-grid-2">
              <div class="form-group">
                <label for="contact-name" class="form-label">Nama Anda *</label>
                <input type="text" id="contact-name" class="form-input" placeholder="Contoh: Budi Santoso" required>
              </div>

              <div class="form-group">
                <label for="contact-phone" class="form-label">Nomor WhatsApp *</label>
                <input type="tel" id="contact-phone" class="form-input" placeholder="Contoh: 081234567890" required>
              </div>
            </div>

            <div class="form-grid-2" style="margin-top: 14px;">
              <div class="form-group">
                <label for="contact-device" class="form-label">Merek & Model HP</label>
                <input type="text" id="contact-device" class="form-input" placeholder="Contoh: Samsung A52 / iPhone 11">
              </div>

              <div class="form-group">
                <label for="contact-issue" class="form-label">Jenis Kerusakan</label>
                <select id="contact-issue" class="form-select">
                  <option value="Layar / LCD Retak atau Blank">Layar / LCD Retak atau Blank</option>
                  <option value="Baterai Cepat Drop / Kembung">Baterai Cepat Drop / Kembung</option>
                  <option value="Tidak Bisa Dicas / Port Rusak">Tidak Bisa Dicas / Port Rusak</option>
                  <option value="HP Mati Total / Terkena Air">HP Mati Total / Terkena Air</option>
                  <option value="Kamera Rusak / Blur">Kamera Rusak / Blur</option>
                  <option value="Speaker / Mic Bermasalah">Speaker / Mic Bermasalah</option>
                  <option value="Software / Bootloop / Lemot">Software / Bootloop / Lemot</option>
                  <option value="Konsultasi Kendala Lainnya">Konsultasi Kendala Lainnya</option>
                </select>
              </div>
            </div>

            <div class="form-group" style="margin-top: 14px;">
              <label for="contact-notes" class="form-label">Catatan Tambahan (Opsional)</label>
              <textarea id="contact-notes" class="form-textarea" rows="3" placeholder="Ceritakan riwayat kerusakan (misal: pernah jatuh, kena percikan air, charger kendor)..."></textarea>
            </div>

            <div style="margin-top: 20px;">
              <button type="submit" class="btn btn-primary btn-block">
                Simulasikan Pengiriman & Tinjau Pesan
              </button>
            </div>

            <!-- Alert Simulasi Front-End Sesuai Persyaratan -->
            <div id="form-simulation-alert" class="simulation-alert"></div>
          </form>
        </div>

      </div>
    </div>
  </section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
