# Reno Cell — Website Company Profile & Smartphone Repair

Website profil perusahaan modern, bersih, dan profesional untuk jasa service dan perbaikan smartphone **Reno Cell**. Dirancang dengan pendekatan desain **Soft Natural, Clean, Minimalist, dan Friendly** dengan palet warna natural *Cream*, *Sage Green*, dan *Olive Green*.

---

## 🌿 Konsep & Karakter Desain

- **Warna Utama**: Cream (`#F6F1E9`), Sage Green (`#DDE6D8`), Olive Green (`#647B61`), Warm White (`#FFFFFF`), Light Beige (`#E8E3DA`), dan Charcoal (`#454942`).
- **Typography**: Plus Jakarta Sans (Google Fonts) dengan hierarki teks yang nyaman dan mudah dibaca oleh semua kalangan usia.
- **Tampilan**: Editorial bersih, kartu rounded (*border radius 12–20px*), shadow lembut, foto realistis aktivitas servis HP, tanpa efek berlebihan seperti cyberpunk/gaming.
- **Responsif**: Dioptimalkan untuk desktop, tablet, dan smartphone (Android & iPhone).

---

## ✨ Fitur-Fitur Website

1. **Sticky Header & Responsive Navigation**
   - Logo Reno Cell dengan identitas visual ramah.
   - Menu navigasi cepat ke semua section landing page.
   - Tombol CTA *"Konsultasi WhatsApp"*.
   - Hamburger drawer menu dengan animasi transisi halus pada perangkat mobile.

2. **Hero Section dengan Visual Realistis**
   - Headline ramah: *"HP Bermasalah? Kami Siap Membantu."*
   - Foto teknisi servis smartphone di meja kerja rapi dengan pencahayaan alami.
   - Tiga poin keunggulan utama (*Konsultasi mudah, Estimasi biaya transparan, Pelayanan ramah*).

3. **Trust Bar 4 Poin**
   - Pemeriksaan awal, estimasi biaya, kemudahan konsultasi, dan kepastian informasi garansi.

4. **Katalog 8 Layanan Servis Utama**
   - Ganti LCD & Touchscreen.
   - Penggantian Baterai.
   - Perbaikan Port Charger.
   - Speaker & Mikrofon.
   - Perbaikan Kamera.
   - Tombol Power & Volume.
   - Pemeriksaan HP Mati Total.
   - Software Troubleshooting & Bootloop.
   - Dilengkapi foto realistis, perkiraan durasi, dan tombol direct chat WhatsApp per layanan.

5. **Dukungan Merek Smartphone**
   - Wordmark merek: Apple / iPhone, Samsung, Xiaomi, Redmi, OPPO, vivo, realme.
   - Disertai catatan independensi dan konfirmasi stok suku cadang.

6. **4 Keunggulan Reno Cell**
   - Penjelasan kerusakan mudah dipahami tanpa istilah teknis rumit.
   - Estimasi biaya sebelum pengerjaan tanpa biaya tersembunyi.
   - Konsultasi praktis via chat.
   - Proses servis transparan.

7. **Tahapan Alur Servis**
   - 01. Konsultasi &rarr; 02. Pemeriksaan &rarr; 03. Persetujuan &rarr; 04. Perbaikan.

8. **Estimasi Biaya Servis Interaktif (`estimator.js`)**
   - Pilihan Merek, Seri/Model, dan Jenis Kerusakan.
   - Menampilkan perkiraan rentang harga, estimasi durasi, dan masa garansi.
   - Diberi penanda *Contoh/Simulasi Demo* secara transparan.
   - Tombol *"Tanyakan via WhatsApp"* yang otomatis merangkum data pilihan pelanggan ke pesan WhatsApp.

9. **Cek Kendala HP Interaktif (`main.js`)**
   - 7 pilihan gejala kerusakan umum (Layar pecah, baterai drop, tidak bisa dicas, HP mati, speaker bermasalah, lemot, kamera blur).
   - Penjelasan kemungkinan penyebab, tips penanganan mandiri yang aman, dan tombol konsultasi.

10. **Tentang Reno Cell & Testimoni Format Demo**
    - Profil workshop, nilai kejujuran, dan jam operasional.
    - Format ulasan pelanggan bertanda *Demo/Template* yang siap diisi ulasan asli.

11. **Accordion FAQ (Tanya Jawab)**
    - Menjawab 7 pertanyaan seputar estimasi durasi, konsultasi awal, biaya, tipe HP, garansi, privasi data, dan janji temu.

12. **Kontak & Formulir Simulasi Front-End**
    - Alamat, jam buka, area Google Maps, dan nomor WhatsApp.
    - Form simulasi front-end dengan validasi input dan opsi langsung meneruskan pesan ke WhatsApp teknisi.

13. **Floating WhatsApp Button**
    - Tombol WhatsApp mengambang di kanan bawah dengan tooltip dan indikator aktif.
    - Pesan otomatis terformat rapi.

14. **Chatbot Front-End: Reno Cell Assistant (`chatbot.js`)**
    - CS Front-End interaktif dengan quick replies dan pencocokan kata kunci (LCD, baterai, biaya, alamat, garansi, dll).
    - Desain panel modern ramah, bubble chat natural, dan tombol meneruskan chat ke WhatsApp teknisi.
    - Terpisah di file tersendiri sehingga siap dihubungkan ke backend AI pada pengembangan selanjutnya.

---

## 📁 Struktur Direktori Proyek

```text
renocell/
├── index.php                 # Halaman utama landing page
├── README.md                 # Dokumentasi proyek lengkap
├── .gitignore                # Filter file Git
├── config/
│   └── site.php              # Konfigurasi terpusat (No. WA, alamat, data layanan)
├── includes/
│   ├── header.php            # Head, CSS, dan Navbar
│   └── footer.php            # Footer, Floating WA, dan Chatbot Widget
└── assets/
    ├── css/
    │   └── style.css         # Desain sistem & styling responsif
    ├── js/
    │   ├── main.js           # Interaktivitas navbar, accordion, kendala HP, & form
    │   ├── chatbot.js        # Engine chatbot Reno Cell Assistant
    │   └── estimator.js      # Logika kalkulasi estimasi harga demo
    └── images/
        ├── hero-repair.jpg   # Foto hero teknisi servis
        ├── about-store.jpg   # Foto workshop servis
        ├── service-lcd.jpg   # Foto perbaikan LCD
        ├── service-battery.jpg
        ├── service-charging.jpg
        ├── service-speaker.jpg
        ├── service-camera.jpg
        ├── service-button.jpg
        ├── service-deadphone.jpg
        └── service-software.jpg
```

---

## 🚀 Cara Menjalankan Melalui XAMPP

1. **Pastikan XAMPP Terpasang**:
   - Pasang XAMPP dari [apachefriends.org](https://www.apachefriends.org/) jika belum terpasang.

2. **Tempatkan Folder Proyek**:
   - Pastikan folder `renocell` berada di direktori `htdocs`, yaitu:
     ```text
     C:\xampp\htdocs\renocell
     ```

3. **Jalankan Apache di XAMPP Control Panel**:
   - Buka aplikasi **XAMPP Control Panel**.
   - Klik tombol **Start** pada modul **Apache**. Pastikan status berubah menjadi hijau (Port 80/443 aktif).

4. **Buka di Browser**:
   - Buka Google Chrome, Microsoft Edge, atau Mozilla Firefox.
   - Ketikkan alamat:
     ```text
     http://localhost/renocell
     ```
   - Website Reno Cell siap diakses dan digunakan sepenuhnya.

---

## ⚙️ Cara Mengubah Nomor WhatsApp & Informasi Bisnis

Semua informasi bisnis tersentralisasi di dalam satu file agar Anda tidak perlu mengedit kode HTML satu per satu:

1. Buka file:
   ```text
   config/site.php
   ```
2. Temukan bagian konfigurasi berikut:
   ```php
   $siteConfig = [
       'brand_name'       => 'Reno Cell',
       'tagline'          => 'Solusi Servis Smartphone Ramah & Transparan',
       
       // Ganti dengan nomor WhatsApp aktif Anda (awali dengan 62 tanpa spasi atau +)
       'whatsapp_number'  => '6281234567890',
       'whatsapp_display' => '+62 812-3456-7890',
       
       // Ganti dengan alamat workshop Anda
       'address_street'   => 'Jl. Anggrek Cendrawasih No. 28',
       'address_city'     => 'Jakarta Barat, DKI Jakarta 11480',
       'google_maps_url'  => 'https://maps.google.com/?q=Lokasi+Reno+Cell',
       
       // Ganti jam operasional
       'hours_weekdays'   => 'Senin – Sabtu: 09.00 – 20.00 WIB',
       'hours_sunday'     => 'Minggu: 10.00 – 17.00 WIB',
       ...
   ];
   ```
3. Simpan file (`Ctrl + S`). Semua tombol WhatsApp (Navbar, Hero, Floating Button, Estimator, Chatbot, Layanan, Kontak) akan otomatis terhubung ke nomor baru Anda!

---

## 🖼️ Cara Mengganti Foto dan Aset Gambar

Semua gambar tersimpan secara lokal di folder `assets/images/`:
- `hero-repair.jpg` &rarr; Foto utama di section atas (Hero).
- `about-store.jpg` &rarr; Foto workshop di section Tentang Reno Cell.
- `service-*.jpg` &rarr; Foto untuk masing-masing kartu layanan perbaikan.

Untuk mengganti gambar:
1. Siapkan foto berformat JPG/PNG/WebP dengan rasio 4:3 atau 16:9 yang bersih dan beresolusi baik.
2. Ganti file di dalam `assets/images/` dengan nama file yang sama, atau perbarui path gambar di file `config/site.php`.

---

## 🐙 Cara Mengunggah Proyek ke GitHub

Ikuti langkah-langkah berikut untuk mengunggah proyek ini ke repository GitHub Anda:

1. **Buka Terminal / Command Prompt**:
   Masuk ke folder proyek:
   ```bash
   cd C:\xampp\htdocs\renocell
   ```

2. **Inisialisasi Git Repository**:
   ```bash
   git init
   ```

3. **Tambahkan File dan Buat Commit Pertama**:
   ```bash
   git add .
   git commit -m "feat: initial release Reno Cell landing page"
   ```

4. **Buat Repository Baru di GitHub**:
   - Buka [github.com/new](https://github.com/new).
   - Beri nama repository (misalnya `reno-cell` atau `renocell-web`).
   - Pilih *Public* atau *Private*. Jangan centang *"Initialize this repository with a README"* karena file README sudah dibuat di proyek ini.
   - Klik **Create repository**.

5. **Hubungkan Remote & Push ke GitHub**:
   ```bash
   git branch -M main
   git remote add origin https://github.com/USERNAME/reno-cell.git
   git push -u origin main
   ```
   *(Ganti `USERNAME` dengan username akun GitHub Anda).*

> **Keamanan Repository**: Proyek ini tidak menyimpan kredensial database, password, maupun secret API key. File `.gitignore` sudah disiapkan untuk mencegah file sementara terunggah.

---

## 💡 Teknologi yang Digunakan

- **HTML5**: Struktur semantik yang ramah SEO dan aksesibilitas.
- **CSS3**: Sistem kustom tanpa framework berat, responsif dengan CSS Grid dan Flexbox.
- **Vanilla JavaScript (ES6+)**:
  - `main.js`: Scroll reveal, hamburger drawer, accordion, dan symptom switcher.
  - `estimator.js`: Kalkulasi estimasi harga dinamis.
  - `chatbot.js`: Asisten simulasi CS front-end.
- **PHP Native**: Template engine modular (`config`, `header`, `footer`) yang langsung kompatibel dengan Apache XAMPP dan shared hosting.
- **Google Fonts**: Plus Jakarta Sans.
- **Lucide Icons**: Ikon modern dan minimalis.

---

## 📄 Lisensi & Hak Cipta

© Reno Cell. Dikembangkan untuk kebutuhan profil bisnis dan perbaikan smartphone.
